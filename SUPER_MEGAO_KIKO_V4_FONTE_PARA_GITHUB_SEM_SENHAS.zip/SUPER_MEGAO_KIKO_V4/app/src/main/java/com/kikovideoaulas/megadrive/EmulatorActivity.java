package com.kikovideoaulas.megadrive;

import android.app.AlertDialog;
import android.content.SharedPreferences;
import android.view.InputDevice;
import android.content.pm.ActivityInfo;
import android.graphics.Color;
import android.graphics.Canvas;
import android.graphics.Paint;
import android.graphics.RectF;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.os.Build;
import android.os.Bundle;
import android.os.Handler;
import android.os.Looper;
import android.content.Intent;
import android.database.Cursor;
import android.provider.DocumentsContract;
import android.provider.DocumentsContract.Document;
import android.net.Uri;
import android.util.Log;
import android.view.Gravity;
import android.view.KeyEvent;
import android.view.MotionEvent;
import android.view.View;
import android.view.WindowInsets;
import android.view.WindowInsetsController;
import android.widget.FrameLayout;
import android.widget.LinearLayout;
import android.widget.TextView;
import android.widget.EditText;
import android.widget.Toast;

import androidx.activity.ComponentActivity;
import com.swordfish.libretrodroid.GLRetroView;
import com.swordfish.libretrodroid.GLRetroViewData;

import java.io.File;
import java.util.zip.ZipFile;
import java.util.zip.ZipEntry;
import java.io.InputStream;
import java.io.BufferedReader;
import java.io.InputStreamReader;
import java.io.ByteArrayInputStream;
import java.io.FileOutputStream;
import java.io.ByteArrayOutputStream;
import java.net.HttpURLConnection;
import java.net.URL;
import java.net.URLEncoder;
import java.nio.charset.StandardCharsets;
import java.util.Locale;
import java.util.TreeMap;
import java.util.Map;
import java.util.Collections;
import java.nio.file.Files;
import java.util.ArrayList;
import java.util.HashSet;
import java.util.Arrays;
import java.util.Comparator;
import java.util.LinkedHashSet;
import java.util.Set;
import java.util.List;

/** KIKO MEGA DRIVE: Genesis Plus GX, Master System e multitoque real. */
public class EmulatorActivity extends ComponentActivity {
    public static final String EXTRA_CAMINHO = "kiko.rom.caminho";
    public static final String EXTRA_NOME = "kiko.rom.nome";

    private static final String TAG = "KikoGenesisGX";
    private GLRetroView retro;
    private File estado;
    private File sram;
    private volatile boolean pronto = false;
    private float opacidade = 0.38f;
    private ControlesMega controles;
    private FrameLayout raizEmulador;
    private volatile boolean encerrandoEmulacao = false;
    // LibretroDroid mantem um nucleo nativo por processo. Duas telas de jogo
    // nao podem inicializar o mesmo nucleo ao mesmo tempo.
    private static final java.util.concurrent.atomic.AtomicBoolean SESSAO_ATIVA =
        new java.util.concurrent.atomic.AtomicBoolean(false);
    private boolean donoDaSessao = false;
    private boolean sistemaMaster;

    // KIKO V14: entrada Bluetooth e virtual compartilham o mesmo estado.
    private final Set<Integer> virtuaisAtivos = new HashSet<>();
    private final Set<Integer> fisicosAtivos = new HashSet<>();
    private final Set<Integer> analogicosAtivos = new HashSet<>();
    private final Set<Integer> comandosEnviados = new HashSet<>();
    private boolean mostrarVirtuais = true;
    private SharedPreferences preferenciasControle;
    private static final String PREF_CONTROLE = "kiko_megadrive_controles";
    private static final int[] ACOES_SN = {
        KeyEvent.KEYCODE_BUTTON_Y, KeyEvent.KEYCODE_BUTTON_B,
        KeyEvent.KEYCODE_BUTTON_A, KeyEvent.KEYCODE_BUTTON_L1,
        KeyEvent.KEYCODE_BUTTON_X, KeyEvent.KEYCODE_BUTTON_R1,
        KeyEvent.KEYCODE_BUTTON_START, KeyEvent.KEYCODE_BUTTON_SELECT
    };
    private static final String[] ROTULOS_SN = {
        "A (Mega Drive)", "B (Mega Drive / Master 1)", "C (Mega Drive / Master 2)",
        "X", "Y", "Z", "START", "MODE"
    };

    // V15: carregador de cheats .cht, separados por jogo e desativados por padrao.
    private static final String PREFERENCIAS_CHEATS = "kiko_mega_cheats_";
    private static final int IMPORTAR_CHT = 1515;
    private static final int PASTA_CHT = 1717;
    private static final String PREF_PASTA_CHT = "kiko_mega_colecao_cht";
    private static byte[] retornoEstadoCheats;
    private static byte[] retornoSramCheats;
    private static String retornoRomCheats;
    private final Handler filaCheats = new Handler(Looper.getMainLooper());
    private volatile boolean cheatsInicializados = false;
    private String caminhoRomAtual;
    private String jogoCheatNome;
    private String tituloInterno;
    private SharedPreferences prefsCheats;
    private final List<CodigoCheat> cheatsDoJogo = new ArrayList<>();

    private static final class CodigoCheat {
        final String descricao;
        final String codigo;
        CodigoCheat(String descricao, String codigo) {
            this.descricao = descricao;
            this.codigo = codigo;
        }
    }

    // Cheats sao importados de arquivos .cht do jogo correto ou buscados no banco
    // Libretro. Nao reutilizar cheats de SNES: os codigos sao incompatíveis.

    private int dp(float n) {
        return Math.round(n * getResources().getDisplayMetrics().density);
    }

    private GradientDrawable fundo(int cor, float raio) {
        GradientDrawable f = new GradientDrawable();
        f.setColor(cor);
        f.setCornerRadius(dp(raio));
        return f;
    }

    // Corrige o NullPointerException do Android (EmulatorActivity, linha 58 da V7).
    // Nao solicita o WindowInsetsController antes de a tela estar anexada.
    private void esconderBarras() {
        final View decor = getWindow().getDecorView();
        decor.post(() -> {
            if (isFinishing() || isDestroyed()) return;
            try {
                getWindow().setStatusBarColor(Color.BLACK);
                getWindow().setNavigationBarColor(Color.BLACK);
                if (Build.VERSION.SDK_INT >= 30) {
                    WindowInsetsController controle = decor.getWindowInsetsController();
                    if (controle != null) {
                        getWindow().setDecorFitsSystemWindows(false);
                        controle.setSystemBarsBehavior(
                            WindowInsetsController.BEHAVIOR_SHOW_TRANSIENT_BARS_BY_SWIPE);
                        controle.hide(WindowInsets.Type.statusBars() |
                            WindowInsets.Type.navigationBars());
                        return;
                    }
                }
                esconderBarrasLegado(decor);
            } catch (RuntimeException falha) {
                Log.w(TAG, "Nao foi possivel aplicar tela cheia", falha);
                esconderBarrasLegado(decor);
            }
        });
    }

    private void esconderBarrasLegado(View decor) {
        decor.setSystemUiVisibility(
            View.SYSTEM_UI_FLAG_FULLSCREEN |
            View.SYSTEM_UI_FLAG_HIDE_NAVIGATION |
            View.SYSTEM_UI_FLAG_IMMERSIVE_STICKY |
            View.SYSTEM_UI_FLAG_LAYOUT_FULLSCREEN |
            View.SYSTEM_UI_FLAG_LAYOUT_HIDE_NAVIGATION |
            View.SYSTEM_UI_FLAG_LAYOUT_STABLE);
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        // Orientacao landscape vem do AndroidManifest.xml desde o lancamento.
        // Evita forcar uma segunda mudanca enquanto Genesis Plus GX inicia.
        preferenciasControle = getSharedPreferences(PREF_CONTROLE, MODE_PRIVATE);
        mostrarVirtuais = preferenciasControle.getBoolean("mostrar_botoes", true);

        String caminho = getIntent().getStringExtra(EXTRA_CAMINHO);
        caminhoRomAtual = caminho;
        if (caminho == null || !new File(caminho).isFile()) {
            avisar("ROM nao localizada. Importe novamente pela biblioteca.");
            finish();
            return;
        }

        sistemaMaster = identificarMasterSystem(caminho);
        prepararCheats(caminho);

        // Cada nucleo tem seus proprios estados; evita carregar saves de outro nucleo.
        File pasta = new File(getFilesDir(), "saves/genesis_plus_gx");
        if (!pasta.exists() && !pasta.mkdirs()) {
            avisar("Nao consegui criar a pasta de salvamentos.");
            finish();
            return;
        }
        String id = new File(caminho).getName().replaceAll("[^a-zA-Z0-9._-]", "_");
        estado = new File(pasta, id + ".state");
        sram = new File(pasta, id + ".srm");

        File core = new File(getApplicationInfo().nativeLibraryDir, "libgenesis_plus_gx_libretro_android.so");
        if (!core.isFile()) {
            new AlertDialog.Builder(this).setTitle("Genesis Plus GX nao encontrado")
                .setMessage("O aplicativo nao possui o nucleo Genesis Plus GX. Recompile o projeto Mega Drive, com internet ligada. Instale o APK gerado pelo Gradle com internet ativa.")
                .setPositiveButton("OK", (d, w) -> finish())
                .setCancelable(false).show();
            return;
        }

        if (!SESSAO_ATIVA.compareAndSet(false, true)) {
            new AlertDialog.Builder(this)
                .setTitle("Aguarde o jogo anterior fechar")
                .setMessage("O nucleo do jogo anterior ainda esta sendo encerrado. " +
                    "Toque em OK e tente novamente em alguns segundos.")
                .setPositiveButton("OK", (d, w) -> finish())
                .setCancelable(false).show();
            return;
        }
        donoDaSessao = true;
        try {
            GLRetroViewData dados = new GLRetroViewData(this);
            dados.setCoreFilePath(core.getAbsolutePath());
            dados.setGameFilePath(caminho);
            dados.setSystemDirectory(getFilesDir().getAbsolutePath());
            dados.setSavesDirectory(pasta.getAbsolutePath());
            // Somente SRAM criada pelo Genesis Plus GX; nunca reaproveita state de outro nucleo.
            if (caminho.equals(retornoRomCheats) && retornoSramCheats != null) {
                dados.setSaveRAMState(retornoSramCheats);
            } else if (sram.isFile() && sram.length() > 0) {
                try {
                    dados.setSaveRAMState(Files.readAllBytes(sram.toPath()));
                } catch (Exception e) {
                    Log.w(TAG, "Falha ao ler SRAM anterior", e);
                }
            }

            Log.i(TAG, "Iniciando apenas Genesis Plus GX. Arquivo=" + new File(caminho).getName());
            retro = new GLRetroView(this, dados);
            retro.setFocusable(true);
            retro.setFocusableInTouchMode(true);
            montarTela();
            esconderBarras();
            // GLRetroView acompanha automaticamente onStart/onResume/onPause/onStop.
            getLifecycle().addObserver(retro);
            pronto = true;
            retro.requestFocus();
            // Nao chamar serializacao do nucleo na thread da interface:
            // se o GL estiver pausado, isso bloquearia a tela e poderia causar ANR.
            if (!cheatsDoJogo.isEmpty() ||
                (caminho.equals(retornoRomCheats) && retornoEstadoCheats != null)) {
                filaCheats.postDelayed(() -> iniciarCheatsEmSegundoPlano(0), 650);
            } else {
                cheatsInicializados = true;
            }
        } catch (Throwable falha) {
            Log.e(TAG, "Falha ao montar Genesis Plus GX", falha);
            new AlertDialog.Builder(this).setTitle("Erro ao abrir jogo")
                .setMessage("Falha na inicializacao do Genesis Plus GX:\n" + falha.toString())
                .setPositiveButton("Fechar", (d, w) -> finish())
                .setCancelable(false).show();
        }
    }

    // Todos os toques ficam nesta UNICA View. A cada evento contamos
    // TODOS os dedos ativos para que Y+Correr e B+Pular funcionem juntos.
    private final class ControlesMega extends View {
        private final Paint tinta = new Paint(Paint.ANTI_ALIAS_FLAG);
        private final List<Tecla> teclas = new ArrayList<>();
        private final Set<Integer> pressionadas = new HashSet<>();
        private final int SEM_BOTAO = -1000;
        private final int CODIGO_MENU = -1;

        private final class Tecla {
            String letra;
            int codigo, cor;
            RectF area;
            Tecla(String letra, int codigo, int cor, float x, float y, float w, float h) {
                this.letra = letra;
                this.codigo = codigo;
                this.cor = cor;
                this.area = new RectF(x, y, x + w, y + h);
            }
        }

        ControlesMega() {
            super(EmulatorActivity.this);
            setClickable(true);
            setFocusable(false);
        }

        private void add(String label, int codigo, int cor,
                         float x, float y, float largura, float altura) {
            teclas.add(new Tecla(label, codigo, cor, x, y, largura, altura));
        }

        // V2: um D-pad UNICO em cruz. Pressionar os cantos envia duas
        // direcoes simultaneamente, sem precisar apertar dois botoes.
        private final RectF areaCruz = new RectF();
        private final Paint tintaCruz = new Paint(Paint.ANTI_ALIAS_FLAG);

        private void montarPosicoes(int w, int h) {
            teclas.clear();
            areaCruz.setEmpty();
            if (w <= 0 || h <= 0) return;
            final boolean emPe = h > w;
            final float margem = dp(9);
            final float yMenu = dp(11);
            add("☰", CODIGO_MENU, 0xFF30323D,
                (w - dp(53)) / 2f, yMenu, dp(53), dp(41));

            // No retrato, dimensiona os grupos pela largura da tela.
            // Na horizontal, usa a faixa lateral NEGRA reservada ao lado
            // da area do jogo. Assim o controle nao invade a imagem.
            final float lado;
            final float grupo;
            final float esquerdo;
            final float direito;
            final float topo;
            if (emPe) {
                final float separacao = dp(52);
                lado = Math.max(dp(70), (w - separacao) / 2f);
                grupo = Math.min(dp(145), Math.max(dp(70), (w - 2f * margem - separacao) / 2f));
                esquerdo = margem;
                direito = w - margem - grupo;
                topo = Math.max(dp(78), h - dp(83) - grupo);
            } else {
                // O mesmo calculo e usado para diminuir a area de video.
                lado = Math.min(dp(152), Math.max(dp(100), w * .27f));
                grupo = Math.min(dp(139), lado - 2f * margem);
                esquerdo = margem;
                direito = w - margem - grupo;
                topo = Math.max(dp(71), h - grupo - dp(26));
            }
            areaCruz.set(esquerdo, topo, esquerdo + grupo, topo + grupo);

            if (sistemaMaster) {
                // Master System usa apenas 1 e 2.
                final float tam = Math.min(dp(62), grupo * .43f);
                final float baseY = topo + (grupo - tam) * .48f;
                add("1", KeyEvent.KEYCODE_BUTTON_B, 0xFFC52C47,
                    direito + dp(1), baseY + dp(12), tam, tam);
                add("2", KeyEvent.KEYCODE_BUTTON_A, 0xFF2879D7,
                    direito + grupo - tam, baseY - dp(12), tam, tam);
            } else {
                // So os tres botoes A B C na tela: 3 botoes em arco,
                // em vez da antiga grade X Y Z / A B C.
                final float diametro = Math.min(dp(59), (grupo - 2f * dp(4)) / 3f);
                final float primeiro = direito + dp(1);
                final float passo = (grupo - diametro) / 2f;
                final float elevacao = Math.min(dp(13), grupo * .10f);
                final float linha = topo + (grupo - diametro) * .56f;
                add("A", KeyEvent.KEYCODE_BUTTON_Y, 0xFFC9304B,
                    primeiro, linha + elevacao, diametro, diametro);
                add("B", KeyEvent.KEYCODE_BUTTON_B, 0xFFC9304B,
                    primeiro + passo, linha, diametro, diametro);
                add("C", KeyEvent.KEYCODE_BUTTON_A, 0xFFC9304B,
                    primeiro + passo * 2f, linha - elevacao, diametro, diametro);
            }
            final float centroW = dp(67);
            final float gap = dp(9);
            final float yCentro = emPe ? h - dp(45) : h - dp(47);
            add("MODE", KeyEvent.KEYCODE_BUTTON_SELECT, 0xFF41434E,
                (w - 2f * centroW - gap) / 2f, yCentro, centroW, dp(33));
            add("START", KeyEvent.KEYCODE_BUTTON_START, 0xFF41434E,
                (w + gap) / 2f, yCentro, centroW, dp(33));
        }

        private void pintarDirecional(Canvas canvas) {
            if (areaCruz.isEmpty() || !mostrarVirtuais) return;
            final float x = areaCruz.left;
            final float y = areaCruz.top;
            final float total = areaCruz.width();
            final float um = total / 3f;
            final float raio = dp(9);
            final boolean acima = pressionadas.contains(KeyEvent.KEYCODE_DPAD_UP);
            final boolean abaixo = pressionadas.contains(KeyEvent.KEYCODE_DPAD_DOWN);
            final boolean esquerda = pressionadas.contains(KeyEvent.KEYCODE_DPAD_LEFT);
            final boolean direita = pressionadas.contains(KeyEvent.KEYCODE_DPAD_RIGHT);
            tintaCruz.setStyle(Paint.Style.FILL);
            tintaCruz.setColor(0xFF343740);
            tintaCruz.setAlpha(Math.round(255f * opacidade));
            // Desenha uma cruz inteira, nao quatro botoes separados.
            canvas.drawRoundRect(x + um, y, x + 2f * um, y + total, raio, raio, tintaCruz);
            canvas.drawRoundRect(x, y + um, x + total, y + 2f * um, raio, raio, tintaCruz);
            // As pontas iluminam em tempo real durante os movimentos diagonais.
            tintaCruz.setColor(0xFF5882CA);
            tintaCruz.setAlpha(Math.round(220f * Math.min(1f, opacidade + .35f)));
            if (acima) canvas.drawRoundRect(x + um, y, x + 2f * um, y + um, raio, raio, tintaCruz);
            if (abaixo) canvas.drawRoundRect(x + um, y + 2f * um, x + 2f * um, y + total, raio, raio, tintaCruz);
            if (esquerda) canvas.drawRoundRect(x, y + um, x + um, y + 2f * um, raio, raio, tintaCruz);
            if (direita) canvas.drawRoundRect(x + 2f * um, y + um, x + total, y + 2f * um, raio, raio, tintaCruz);
            tintaCruz.setTypeface(Typeface.create(Typeface.DEFAULT, Typeface.BOLD));
            tintaCruz.setTextAlign(Paint.Align.CENTER);
            tintaCruz.setTextSize(Math.min(dp(23), um * .54f));
            tintaCruz.setColor(Color.WHITE);
            tintaCruz.setAlpha(235);
            final Paint.FontMetrics fm = tintaCruz.getFontMetrics();
            final float offset = -(fm.ascent + fm.descent) / 2f;
            canvas.drawText("▲", x + total / 2f, y + um / 2f + offset, tintaCruz);
            canvas.drawText("▼", x + total / 2f, y + total - um / 2f + offset, tintaCruz);
            canvas.drawText("◀", x + um / 2f, y + total / 2f + offset, tintaCruz);
            canvas.drawText("▶", x + total - um / 2f, y + total / 2f + offset, tintaCruz);
            // Marcas dos quadrantes diagonais. As quatro esquinas sao clicaveis.
            tintaCruz.setTextSize(Math.min(dp(16), um * .43f));
            tintaCruz.setAlpha(185);
            canvas.drawText("↖", x + um / 2f, y + um / 2f + offset, tintaCruz);
            canvas.drawText("↗", x + total - um / 2f, y + um / 2f + offset, tintaCruz);
            canvas.drawText("↙", x + um / 2f, y + total - um / 2f + offset, tintaCruz);
            canvas.drawText("↘", x + total - um / 2f, y + total - um / 2f + offset, tintaCruz);
        }

        private void adicionarToque(float x, float y, Set<Integer> conjunto) {
            if (mostrarVirtuais && areaCruz.contains(x, y)) {
                final float raio = areaCruz.width() / 2f;
                final float nx = (x - areaCruz.centerX()) / raio;
                final float ny = (y - areaCruz.centerY()) / raio;
                final float ax = Math.abs(nx);
                final float ay = Math.abs(ny);
                // Um dedo no centro neutro nao manda comandos opostos.
                if (ax < .15f && ay < .15f) return;
                // Zona angular: acima/abaixo e lado podem ficar ativos juntos.
                // 0.42 suaviza o movimento sem pressionar duas teclas.
                if (ax > ay * .42f && ax > .15f) {
                    conjunto.add(nx < 0f ? KeyEvent.KEYCODE_DPAD_LEFT : KeyEvent.KEYCODE_DPAD_RIGHT);
                }
                if (ay > ax * .42f && ay > .15f) {
                    conjunto.add(ny < 0f ? KeyEvent.KEYCODE_DPAD_UP : KeyEvent.KEYCODE_DPAD_DOWN);
                }
                return;
            }
            final int codigo = codigoEm(x, y);
            if (codigo >= 0) conjunto.add(codigo);
        }

        @Override
        protected void onSizeChanged(int w, int h, int oldw, int oldh) {
            super.onSizeChanged(w, h, oldw, oldh);
            soltarTodos();
            montarPosicoes(w, h);
        }

        @Override
        protected void onDraw(Canvas canvas) {
            super.onDraw(canvas);
            pintarDirecional(canvas);
            for (Tecla b : teclas) {
                if (!mostrarVirtuais && b.codigo != CODIGO_MENU) continue;
                boolean apertado = pressionadas.contains(b.codigo);
                // Somente o desenho fica translúcido; a area tocavel permanece inteira.
                tinta.setStyle(Paint.Style.FILL);
                tinta.setColor(b.cor);
                tinta.setAlpha(Math.round(255 * (apertado ? Math.min(0.88f, opacidade + 0.3f) : opacidade)));
                canvas.drawRoundRect(b.area, dp(16), dp(16), tinta);
                tinta.setColor(Color.WHITE);
                tinta.setAlpha(Math.round(255 * (apertado ? 0.98f : 0.82f)));
                tinta.setTypeface(Typeface.create(Typeface.DEFAULT, Typeface.BOLD));
                tinta.setTextSize(dp(b.letra.length() > 2 ? 11 : 22));
                tinta.setTextAlign(Paint.Align.CENTER);
                Paint.FontMetrics f = tinta.getFontMetrics();
                float cy = b.area.centerY() - (f.ascent + f.descent) / 2f;
                canvas.drawText(b.letra, b.area.centerX(), cy, tinta);
            }
        }

        private int codigoEm(float x, float y) {
            for (Tecla b : teclas) {
                if (!mostrarVirtuais && b.codigo != CODIGO_MENU) continue;
                if (b.area.contains(x, y)) return b.codigo;
            }
            return SEM_BOTAO;
        }

        @Override
        public boolean onTouchEvent(MotionEvent e) {
            int tipo = e.getActionMasked();
            if (tipo == MotionEvent.ACTION_CANCEL) {
                atualizar(new HashSet<>());
                return true;
            }
            if (tipo != MotionEvent.ACTION_DOWN &&
                tipo != MotionEvent.ACTION_POINTER_DOWN &&
                tipo != MotionEvent.ACTION_MOVE &&
                tipo != MotionEvent.ACTION_UP &&
                tipo != MotionEvent.ACTION_POINTER_UP) {
                return true;
            }

            Set<Integer> agora = new HashSet<>();
            int dedoQueSai = (tipo == MotionEvent.ACTION_UP ||
                tipo == MotionEvent.ACTION_POINTER_UP) ? e.getActionIndex() : -1;

            for (int i = 0; i < e.getPointerCount(); i++) {
                if (i == dedoQueSai) continue;
                adicionarToque(e.getX(i), e.getY(i), agora);
            }
            atualizar(agora);

            // Menu so abre ao soltar o dedo que estava sobre ele.
            if (dedoQueSai >= 0 &&
                codigoEm(e.getX(dedoQueSai), e.getY(dedoQueSai)) == CODIGO_MENU) {
                soltarTodos();
                menuRapido();
            }
            return true;
        }

        private void atualizar(Set<Integer> agora) {
            pressionadas.clear();
            pressionadas.addAll(agora);
            virtuaisAtivos.clear();
            virtuaisAtivos.addAll(agora);
            sincronizarComandos();
            invalidate();
        }

        void soltarTodos() {
            pressionadas.clear();
            virtuaisAtivos.clear();
            sincronizarComandos();
            invalidate();
        }

        void redesenhar() { invalidate(); }
    }

    // Reserva duas faixas pretas laterais para os controles horizontais.
    // A imagem permanece centralizada e nunca fica atras dos botoes.
    private void dimensionarVideo(int largura, int altura) {
        if (retro == null || largura <= 0 || altura <= 0) return;
        final boolean deitado = largura > altura;
        final int larguraVideo;
        if (deitado) {
            int ladoReservado = Math.min(dp(152), Math.max(dp(100), Math.round(largura * .27f)));
            larguraVideo = Math.max(1, Math.min(largura - 2 * ladoReservado,
                Math.round(altura * 4f / 3f)));
        } else {
            larguraVideo = -1;
        }
        FrameLayout.LayoutParams atual = (FrameLayout.LayoutParams) retro.getLayoutParams();
        if (atual != null && atual.width == larguraVideo && atual.height == -1 &&
            atual.gravity == Gravity.CENTER) return;
        FrameLayout.LayoutParams nova = new FrameLayout.LayoutParams(larguraVideo, -1, Gravity.CENTER);
        retro.setLayoutParams(nova);
    }

    private void montarTela() {
        raizEmulador = new FrameLayout(this) {
            @Override
            protected void onSizeChanged(int w, int h, int oldw, int oldh) {
                super.onSizeChanged(w, h, oldw, oldh);
                // O motor Libretro acompanha onSurfaceChanged automaticamente.
                dimensionarVideo(w, h);
            }
        };
        raizEmulador.setBackgroundColor(Color.BLACK);
        setContentView(raizEmulador);
        raizEmulador.addView(retro, new FrameLayout.LayoutParams(-1, -1, Gravity.CENTER));
        controles = new ControlesMega();
        raizEmulador.addView(controles, new FrameLayout.LayoutParams(-1, -1));
    }

    private void menuRapido() {
        String[] opcoes = {
            "Salvar partida", "Carregar partida", "Reiniciar",
            "Controles 25%", "Controles 40%", "Controles 60%",
            "Cheats — ativar / desativar",
            mostrarVirtuais ? "Ocultar controles da tela" : "Mostrar controles da tela",
            "Configurar controle Bluetooth", "Restaurar botoes Bluetooth",
            "Ver controles conectados", "Fechar jogo"
        };
        new AlertDialog.Builder(this).setTitle("SUPER MEGAO KIKO • MEGA DRIVE")
            .setItems(opcoes, (dialog, pos) -> {
                if (pos == 0) salvar();
                else if (pos == 1) carregar();
                else if (pos == 2) reiniciar();
                else if (pos == 3) alterarOpacidade(0.25f);
                else if (pos == 4) alterarOpacidade(0.40f);
                else if (pos == 5) alterarOpacidade(0.60f);
                else if (pos == 6) abrirMenuCheats();
                else if (pos == 7) alternarVirtuais();
                else if (pos == 8) configurarBluetooth();
                else if (pos == 9) restaurarBluetooth();
                else if (pos == 10) mostrarDispositivos();
                else if (pos == 11) confirmarSaida();
            }).show();
    }

    // Le o titulo no cabecalho Mega Drive/Genesis, quando presente.
    // Master System normalmente nao possui titulo no cabecalho, entao
    // o nome de origem enviado por MainActivity tem prioridade.
    private String tituloJogo(String caminho) {
        String nome = new File(caminho).getName();
        nome = nome.replaceFirst("(?i)\\.(md|gen|bin|smd|sms|zip)$", "");
        nome = nome.replaceAll("\\[[^]]*\\]", " ");
        nome = nome.replaceAll("(?i)\\([^)]*(usa|europe|japan|world|brasil|br|pt-br|rev|beta|proto|hack)[^)]*\\)", " ");
        return nome.replaceAll("\\s+", " ").trim();
    }

    private String chaveNome(String nome) {
        if (nome == null) return "";
        String semAcentos = java.text.Normalizer.normalize(nome, java.text.Normalizer.Form.NFD)
            .replaceAll("\\p{M}+", "");
        return semAcentos.toLowerCase(Locale.ROOT).replaceAll("[^a-z0-9]", "");
    }

    private boolean identificarMasterSystem(String caminho) {
        if (caminho.toLowerCase(Locale.ROOT).endsWith(".sms")) return true;
        // Arquivos .bin podem conter ROM Master System. Detecta TMR SEGA.
        try (java.io.RandomAccessFile raf = new java.io.RandomAccessFile(caminho, "r")) {
            for (long pos : new long[]{0x1ff0, 0x3ff0, 0x7ff0}) {
                if (raf.length() < pos + 8) continue;
                raf.seek(pos);
                byte[] b = new byte[8];
                raf.readFully(b);
                if ("TMR SEGA".equals(new String(b, StandardCharsets.US_ASCII))) return true;
            }
        } catch (Exception ex) {
            Log.w(TAG, "Falha ao identificar Master System", ex);
        }
        return false;
    }

    private String tituloInternoSega(String caminho) {
        if (sistemaMaster) return "";
        try (java.io.RandomAccessFile raf = new java.io.RandomAccessFile(caminho, "r")) {
            if (raf.length() < 0x150) return "";
            raf.seek(0x120);
            byte[] b = new byte[48];
            raf.readFully(b);
            String titulo = new String(b, StandardCharsets.US_ASCII)
                .replaceAll("[^\\x20-\\x7E]", " ").trim();
            return titulo.length() < 4 ? "" : titulo;
        } catch (Exception ex) {
            Log.w(TAG, "Nao foi possivel ler titulo interno do Mega Drive", ex);
            return "";
        }
    }

    private boolean eNomeHash(String nome) {
        if (nome == null) return true;
        String semExt = nome.replaceFirst("(?i)\\.(md|gen|bin|smd|sms|zip)$", "").trim();
        return semExt.isEmpty() || semExt.matches("(?i)[0-9a-f]{16,64}") ||
            semExt.matches("(?i)(rom|game|jogo)[ _-]*[0-9a-f]{4,}");
    }

    private String nomeBuscaSugerido() {
        String nome = jogoCheatNome == null ? "" : jogoCheatNome.trim();
        if (eNomeHash(nome)) nome = tituloInterno == null ? "" : tituloInterno.trim();
        if (eNomeHash(nome)) nome = "";
        return nome;
    }

    private File arquivoCheatExterno() {
        return new File(new File(getFilesDir(), "cheats"),
            Integer.toHexString(caminhoRomAtual.hashCode()) + ".cht");
    }

    private void prepararCheats(String caminho) {
        // O RomInstaller salva um nome temporario (hash) no cache. A biblioteca
        // ja envia EXTRA_NOME, com o nome que o usuario realmente selecionou.
        String nomeBiblioteca = getIntent().getStringExtra(EXTRA_NOME);
        jogoCheatNome = tituloJogo(
            nomeBiblioteca != null && !nomeBiblioteca.trim().isEmpty()
                ? nomeBiblioteca : caminho);
        prefsCheats = getSharedPreferences(PREFERENCIAS_CHEATS +
            Integer.toHexString(caminho.hashCode()), MODE_PRIVATE);
        tituloInterno = tituloInternoSega(caminho);
        if (eNomeHash(jogoCheatNome) && !eNomeHash(tituloInterno)) {
            jogoCheatNome = tituloInterno;
        }
        Log.i(TAG, "Nome na biblioteca=" + nomeBiblioteca +
            " / titulo Sega=" + tituloInterno + " / busca=" + jogoCheatNome);
        recarregarCheats();
        if (cheatsDoJogo.isEmpty() && !getPreferencesPasta().isEmpty()) {
            pesquisarPastaCheats(null, false);
        }
    }

    private void recarregarCheats() {
        cheatsDoJogo.clear();
        File personalizado = arquivoCheatExterno();
        if (!personalizado.isFile()) return;
        try (InputStream in = new java.io.FileInputStream(personalizado)) {
            cheatsDoJogo.addAll(lerCheats(in));
            Log.i(TAG, "Cheats Sega carregados: " + cheatsDoJogo.size());
        } catch (Exception ex) {
            Log.w(TAG, "Falha ao ler cheats do jogo", ex);
        }
    }

    // Interpreta .cht do Libretro: cheatN_desc, cheatN_code, cheatN_enable.
    // Ignora codigos invalidos, enderecos de busca de memoria e placeholders XX.
    private List<CodigoCheat> lerCheats(InputStream stream) throws Exception {
        TreeMap<Integer, String[]> dados = new TreeMap<>();
        try (BufferedReader br = new BufferedReader(new InputStreamReader(stream,
                StandardCharsets.UTF_8))) {
            String linha;
            while ((linha = br.readLine()) != null) {
                int igual = linha.indexOf('=');
                if (igual < 0) continue;
                String chave = linha.substring(0, igual).trim();
                java.util.regex.Matcher m = java.util.regex.Pattern
                    .compile("cheat(\\d+)_(desc|code)").matcher(chave);
                if (!m.matches()) continue;
                int idx = Integer.parseInt(m.group(1));
                if (idx < 0 || idx > 1999) continue;
                String valor = linha.substring(igual + 1).trim();
                if (valor.length() >= 2 && valor.startsWith("\"") && valor.endsWith("\""))
                    valor = valor.substring(1, valor.length() - 1);
                String[] campos = dados.get(idx);
                if (campos == null) { campos = new String[2]; dados.put(idx, campos); }
                campos[m.group(2).equals("desc") ? 0 : 1] = valor;
            }
        }
        List<CodigoCheat> saida = new ArrayList<>();
        for (Map.Entry<Integer, String[]> entrada : dados.entrySet()) {
            String[] item = entrada.getValue();
            String codigo = item[1];
            if (codigo == null) continue;
            codigo = codigo.trim().toUpperCase(Locale.ROOT).replace(" ", "");
            if (codigo.isEmpty() || codigo.length() > 220) continue;
            String[] partes = codigo.split("\\+");
            boolean valido = partes.length > 0;
            for (String parte : partes) {
                // Genesis Plus GX aceita formatos diferentes para Mega Drive e Master.
                // Mega: Game Genie AAAA-AAAA; Action Replay FFFFFF:0000.
                // Master: Action Replay 00D4-1105; Game Genie C9B-9D8-082;
                // Fusion 0123:45 ou 670123:45, incluindo multiplos codigos com +.
                if (!(parte.matches("[0-9A-F]{8}") ||
                      parte.matches("[A-Z0-9]{4}-[A-Z0-9]{4}") ||
                      parte.matches("[A-Z0-9]{3}-[A-Z0-9]{3}-[A-Z0-9]{3}") ||
                      parte.matches("[A-Z0-9]{3}-[A-Z0-9]{3}") ||
                      parte.matches("[0-9A-F]{4,8}:[0-9A-F]{2,4}"))) {
                    valido = false;
                    break;
                }
            }
            if (!valido) continue;
            String descricao = item[0] == null || item[0].trim().isEmpty()
                ? "Codigo " + (entrada.getKey() + 1) : item[0].trim();
            saida.add(new CodigoCheat(descricao, codigo));
        }
        return saida;
    }

    private Set<String> cheatsAtivos() {
        return new HashSet<>(prefsCheats.getStringSet("ativos", Collections.emptySet()));
    }

    private void salvarCheatsAtivos(Set<String> codigos) {
        prefsCheats.edit().putStringSet("ativos", new HashSet<>(codigos)).commit();
    }

    // O core Genesis Plus GX atual adiciona grupos em retro_cheat_set ignorando o indice.
    // Ao desligar um cheat ja enviado, refazemos apenas o nucleo e restauramos
    // o estado em memoria; isso garante que o codigo desligado pare de atuar.
    private void iniciarCheatsEmSegundoPlano(int tentativa) {
        if (encerrandoEmulacao || isFinishing() || isDestroyed() || !pronto) return;
        new Thread(() -> iniciarCheatsQuandoPronto(tentativa), "KikoCheatsGenesis").start();
    }

    private void iniciarCheatsQuandoPronto(int tentativa) {
        if (encerrandoEmulacao || isFinishing() || isDestroyed() || retro == null || cheatsInicializados) return;
        try {
            byte[] teste = retro.serializeState(true);
            if (teste == null || teste.length < 64) throw new IllegalStateException("ROM carregando");
            if (caminhoRomAtual.equals(retornoRomCheats) && retornoEstadoCheats != null) {
                byte[] snapshot = retornoEstadoCheats;
                if (!retro.unserializeState(snapshot, true))
                    Log.w(TAG, "Nao consegui restaurar o estado apos mudar cheats");
                retornoEstadoCheats = null;
                retornoSramCheats = null;
                retornoRomCheats = null;
            }
            cheatsInicializados = true;
            Set<String> ativos = cheatsAtivos();
            int indice = 0;
            for (CodigoCheat cheat : cheatsDoJogo) {
                if (ativos.contains(cheat.codigo)) {
                    retro.setCheat(indice++, true, cheat.codigo, true);
                }
            }
        } catch (Throwable falha) {
            if (tentativa < 45) {
                filaCheats.postDelayed(() -> iniciarCheatsEmSegundoPlano(tentativa + 1), 330);
            } else {
                Log.e(TAG, "O nucleo nao ficou pronto para aplicar cheats", falha);
                runOnUiThread(() -> {
                    if (!isFinishing() && !isDestroyed())
                        avisar("Cheats indisponiveis: jogo nao ficou pronto.");
                });
            }
        }
    }

    // V17: pasta inteira de .CHT do Libretro, via seletor oficial do Android.
    // A permissao e armazenada pelo Android; nenhum arquivo da ROM e alterado.
    private String getPreferencesPasta() {
        return getSharedPreferences(PREF_PASTA_CHT, MODE_PRIVATE)
            .getString("uri", "");
    }

    private void selecionarPastaCheats() {
        try {
            Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT_TREE);
            intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION |
                Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION);
            startActivityForResult(intent, PASTA_CHT);
        } catch (Exception e) {
            avisar("Nao foi possivel selecionar a pasta: " + e.getMessage());
        }
    }

    private static final class ArquivoCht {
        final String nome;
        final Uri uri;
        final int pontos;
        ArquivoCht(String nome, Uri uri, int pontos) {
            this.nome = nome; this.uri = uri; this.pontos = pontos;
        }
    }

    private int pontosCheat(String arquivo, String busca) {
        String normal = arquivo.replaceFirst("(?i)\\.cht$", "")
            .replaceAll("\\s*\\([^)]*\\)", " ").trim();
        String a = chaveNome(normal);
        String b = chaveNome(busca);
        if (a.isEmpty() || b.isEmpty() || eNomeHash(busca)) return 0;
        if (a.equals(b)) return 400;
        // Aceitar sufixos de regiao e revisao, mas evitar jogo 1 vs jogo 2.
        if (a.startsWith(b) && !a.substring(b.length()).matches("[0-9].*")) return 250;
        if (b.startsWith(a) && !b.substring(a.length()).matches("[0-9].*")) return 180;
        if (b.length() >= 7 && a.contains(b)) return 130;
        return 0;
    }

    private void listarPastaCht(Uri arvore, String pastaId, String busca,
                                List<ArquivoCht> encontrados, int nivel) {
        if (nivel > 2) return;
        Uri filhos = DocumentsContract.buildChildDocumentsUriUsingTree(arvore, pastaId);
        try (Cursor cursor = getContentResolver().query(filhos,
            new String[]{Document.COLUMN_DOCUMENT_ID, Document.COLUMN_DISPLAY_NAME,
                Document.COLUMN_MIME_TYPE}, null, null, null)) {
            if (cursor == null) return;
            while (cursor.moveToNext()) {
                String id = cursor.getString(0);
                String nome = cursor.getString(1);
                String tipo = cursor.getString(2);
                if (nome == null || id == null) continue;
                if (Document.MIME_TYPE_DIR.equals(tipo)) {
                    // Caso o usuario tenha selecionado a pasta geral "cht",
                    // entrar nos diretorios Sega Mega Drive e Master System.
                    String k = chaveNome(nome);
                    if (k.contains("megadrive") || k.contains("genesis") ||
                        k.contains("mastersystem") || k.equals("sega") ||
                        k.equals("cht")) {
                        listarPastaCht(arvore, id, busca, encontrados, nivel + 1);
                    }
                } else if (nome.toLowerCase(Locale.ROOT).endsWith(".cht")) {
                    int pontos = pontosCheat(nome, busca);
                    if (pontos > 0) {
                        Uri documento = DocumentsContract.buildDocumentUriUsingTree(arvore, id);
                        encontrados.add(new ArquivoCht(nome, documento, pontos));
                    }
                }
            }
        }
    }

    private void pesquisarPastaCheats(String nomeSolicitado, boolean mostrarResultado) {
        final String uriSalva = getPreferencesPasta();
        if (uriSalva.isEmpty()) {
            if (mostrarResultado) avisar("Primeiro selecione a pasta de cheats .cht.");
            return;
        }
        final String busca = nomeSolicitado == null ? nomeBuscaSugerido() : nomeSolicitado.trim();
        if (busca.isEmpty() || eNomeHash(busca)) {
            if (mostrarResultado) solicitarNomeCheatPasta();
            return;
        }
        if (mostrarResultado) avisar("Procurando na pasta: " + busca);
        new Thread(() -> {
            try {
                Uri arvore = Uri.parse(uriSalva);
                ArrayList<ArquivoCht> encontrados = new ArrayList<>();
                listarPastaCht(arvore, DocumentsContract.getTreeDocumentId(arvore),
                    busca, encontrados, 0);
                encontrados.sort((a, b) -> {
                    int r = Integer.compare(b.pontos, a.pontos);
                    return r != 0 ? r : a.nome.compareToIgnoreCase(b.nome);
                });
                runOnUiThread(() -> {
                    if (isFinishing() || isDestroyed()) return;
                    if (encontrados.isEmpty()) {
                        if (mostrarResultado) new AlertDialog.Builder(this)
                            .setTitle("Nenhum .cht encontrado")
                            .setMessage("Nao encontrei cheats para '" + busca +
                                "' na pasta escolhida. Confira o titulo original " +
                                "ou selecione a pasta Sega Mega Drive ou Master System do Libretro.")
                            .setPositiveButton("Tentar outro nome", (d, w) -> solicitarNomeCheatPasta())
                            .setNegativeButton("Fechar", null).show();
                        return;
                    }
                    if (!mostrarResultado && encontrados.size() > 0) {
                        // Correspondencia automatica somente se exata, para nao
                        // aplicar cheat de outro jogo por engano.
                        if (encontrados.get(0).pontos >= 400)
                            carregarCheatDaPasta(encontrados.get(0), false);
                        return;
                    }
                    int total = Math.min(35, encontrados.size());
                    String[] nomes = new String[total];
                    for (int i = 0; i < total; i++) nomes[i] = encontrados.get(i).nome;
                    new AlertDialog.Builder(this).setTitle("Cheats de " + busca)
                        .setItems(nomes, (d, pos) -> carregarCheatDaPasta(encontrados.get(pos), true))
                        .setNeutralButton("Outro nome", (d, w) -> solicitarNomeCheatPasta())
                        .setNegativeButton("Cancelar", null).show();
                });
            } catch (Exception e) {
                Log.e(TAG, "Erro ao ler pasta .cht", e);
                if (mostrarResultado) runOnUiThread(() -> avisar(
                    "Nao foi possivel ler a pasta: " + e.getMessage()));
            }
        }, "KikoPastaCheatsV17").start();
    }

    private void solicitarNomeCheatPasta() {
        EditText entrada = new EditText(this);
        entrada.setSingleLine(true);
        entrada.setHint("Nome original do jogo");
        entrada.setText(nomeBuscaSugerido());
        entrada.setSelectAllOnFocus(true);
        new AlertDialog.Builder(this).setTitle("Procurar na pasta Libretro")
            .setMessage("Digite o nome do jogo, nao o codigo do arquivo da ROM.")
            .setView(entrada)
            .setPositiveButton("Procurar", (d, w) -> pesquisarPastaCheats(
                entrada.getText().toString(), true))
            .setNegativeButton("Cancelar", null).show();
    }

    private void carregarCheatDaPasta(ArquivoCht arquivo, boolean mostrar) {
        new Thread(() -> {
            try {
                byte[] bytes;
                try (InputStream in = getContentResolver().openInputStream(arquivo.uri);
                     ByteArrayOutputStream out = new ByteArrayOutputStream()) {
                    if (in == null) throw new Exception("Sem acesso ao arquivo .cht");
                    byte[] buffer = new byte[8192]; int n;
                    while ((n = in.read(buffer)) != -1) {
                        out.write(buffer, 0, n);
                        if (out.size() > 750000) throw new Exception("Arquivo maior que 750 KB");
                    }
                    bytes = out.toByteArray();
                }
                int total = lerCheats(new ByteArrayInputStream(bytes)).size();
                if (total == 0) throw new Exception("Nao encontrei codigos validos no .cht");
                runOnUiThread(() -> {
                    // Nunca sobrescrever um cheat personalizado com codigos ativos.
                    if (!cheatsAtivos().isEmpty()) {
                        new AlertDialog.Builder(this).setTitle("Substituir cheats ativos?")
                            .setMessage("Salve seu progresso. Os cheats anteriores serao desligados.")
                            .setPositiveButton("Substituir", (d, w) -> instalarCheatDaPasta(bytes, total, mostrar))
                            .setNegativeButton("Cancelar", null).show();
                    } else instalarCheatDaPasta(bytes, total, mostrar);
                });
            } catch (Exception e) {
                if (mostrar) runOnUiThread(() -> avisar("Falha no .cht: " + e.getMessage()));
            }
        }, "KikoLerCheatV17").start();
    }

    private void instalarCheatDaPasta(byte[] bytes, int total, boolean mostrar) {
        try {
            File destino = arquivoCheatExterno();
            File parent = destino.getParentFile();
            if (parent != null && !parent.exists()) parent.mkdirs();
            try (FileOutputStream out = new FileOutputStream(destino)) { out.write(bytes); }
            boolean tinha = !cheatsAtivos().isEmpty();
            salvarCheatsAtivos(Collections.emptySet());
            recarregarCheats();
            trocarBancoEReiniciarSeNecessario(tinha);
            if (mostrar) {
                avisar(total + " cheats carregados, todos desligados.");
                abrirMenuCheats();
            }
        } catch (Exception e) {
            avisar("Erro ao salvar .cht: " + e.getMessage());
        }
    }

    private void abrirMenuCheats() {
        recarregarCheats();
        final String[] nomes = new String[cheatsDoJogo.size()];
        final boolean[] marcados = new boolean[nomes.length];
        Set<String> atuais = cheatsAtivos();
        for (int i = 0; i < nomes.length; i++) {
            CodigoCheat ch = cheatsDoJogo.get(i);
            nomes[i] = ch.descricao + "  [" + ch.codigo + "]";
            marcados[i] = atuais.contains(ch.codigo);
        }
        final AlertDialog[] dialogo = new AlertDialog[1];
        AlertDialog.Builder builder = new AlertDialog.Builder(this)
            .setTitle("Cheats • " + jogoCheatNome)
            .setMultiChoiceItems(nomes, marcados, (d, pos, habilitado) -> {
                CodigoCheat ch = cheatsDoJogo.get(pos);
                Set<String> ligados = cheatsAtivos();
                if (habilitado) {
                    if (!cheatsInicializados) {
                        ((AlertDialog) d).getListView().setItemChecked(pos, false);
                        avisar("O jogo ainda esta carregando.");
                        return;
                    }
                    try {
                        // O nucleo Genesis Plus GX aceita cheats Libretro conforme suporte da ROM.
                        retro.setCheat(pos, true, ch.codigo, true);
                        ligados.add(ch.codigo);
                        salvarCheatsAtivos(ligados);
                    } catch (Throwable erro) {
                        ((AlertDialog) d).getListView().setItemChecked(pos, false);
                        avisar("Falha ao ativar cheat: " + erro.getMessage());
                    }
                } else {
                    if (!ligados.contains(ch.codigo)) return;
                    try {
                        byte[] estadoAtual = retro.serializeState(true);
                        if (estadoAtual == null || estadoAtual.length < 64)
                            throw new IllegalStateException("Nao foi possivel preservar a partida");
                        retornoEstadoCheats = estadoAtual;
                        retornoSramCheats = retro.serializeSRAM(true);
                        retornoRomCheats = caminhoRomAtual;
                        ligados.remove(ch.codigo);
                        salvarCheatsAtivos(ligados);
                        ((AlertDialog) d).dismiss();
                        avisar("Cheat desligado. Saia e abra o jogo para aplicar a mudanca.");
                    } catch (Throwable erro) {
                        ((AlertDialog) d).getListView().setItemChecked(pos, true);
                        avisar("Falha ao desativar: " + erro.getMessage());
                    }
                }
            })
            .setPositiveButton("Mais opcoes", (d, w) -> abrirOpcoesCheats())
            .setNeutralButton("Buscar online", (d, w) -> buscarCheatsOnline())
            .setNegativeButton("Fechar", null);
        if (nomes.length == 0) builder.setMessage(
            "Nenhum cheat encontrado automaticamente. Toque em MAIS OPCOES " +
            "para importar um .cht, procurar em uma pasta ou buscar online, " +
            "Nome da ROM: " + jogoCheatNome);
        dialogo[0] = builder.create();
        dialogo[0].show();
    }

    private void abrirOpcoesCheats() {
        String[] opcoes = {
            "Importar arquivo de cheats .cht",
            "Pesquisar cheats do jogo na internet",
            "Selecionar pasta de cheats .cht",
            "Procurar cheats na pasta selecionada"
        };
        new AlertDialog.Builder(this)
            .setTitle("Biblioteca de cheats • SEGA")
            .setItems(opcoes, (d, qual) -> {
                if (qual == 0) importarArquivoCheat();
                else if (qual == 1) buscarCheatsOnline();
                else if (qual == 2) selecionarPastaCheats();
                else if (qual == 3) solicitarNomeCheatPasta();
            }).setNegativeButton("Voltar", null).show();
    }

    private void trocarBancoEReiniciarSeNecessario(boolean haviaCheatsAtivos) {
        if (!haviaCheatsAtivos || !cheatsInicializados || retro == null) return;
        filaCheats.postDelayed(() -> {
            if (isFinishing() || isDestroyed() || retro == null) return;
            try {
                byte[] snapshot = retro.serializeState(true);
                if (snapshot == null || snapshot.length < 64) return;
                retornoEstadoCheats = snapshot;
                retornoSramCheats = retro.serializeSRAM(true);
                retornoRomCheats = caminhoRomAtual;
                avisar("Feche e abra a partida para atualizar os cheats.");
            } catch (Throwable e) {
                Log.e(TAG, "Falha ao atualizar o banco de cheats", e);
                avisar("Reabra o jogo para aplicar os novos cheats.");
            }
        }, 650);
    }

    private void importarArquivoCheat() {
        try {
            Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
            intent.setType("*/*");
            intent.addCategory(Intent.CATEGORY_OPENABLE);
            startActivityForResult(intent, IMPORTAR_CHT);
        } catch (Exception erro) {
            avisar("Nao foi possivel abrir o seletor de arquivos.");
        }
    }

    @Override
    protected void onActivityResult(int req, int res, Intent dados) {
        super.onActivityResult(req, res, dados);
        if (req == PASTA_CHT) {
            if (res == RESULT_OK && dados != null && dados.getData() != null) {
                try {
                    Uri arvore = dados.getData();
                    getContentResolver().takePersistableUriPermission(arvore,
                        Intent.FLAG_GRANT_READ_URI_PERMISSION);
                    getSharedPreferences(PREF_PASTA_CHT, MODE_PRIVATE).edit()
                        .putString("uri", arvore.toString()).apply();
                    avisar("Pasta de cheats registrada! Procurando codigos...");
                    pesquisarPastaCheats(null, true);
                } catch (Exception ex) {
                    avisar("Falha ao autorizar pasta: " + ex.getMessage());
                }
            }
            return;
        }
        if (req != IMPORTAR_CHT || res != RESULT_OK || dados == null || dados.getData() == null)
            return;
        try {
            Uri uri = dados.getData();
            byte[] bytes;
            try (InputStream in = getContentResolver().openInputStream(uri);
                 ByteArrayOutputStream buf = new ByteArrayOutputStream()) {
                if (in == null) throw new Exception("Arquivo nao acessivel");
                byte[] bloco = new byte[8192];
                int n;
                while ((n = in.read(bloco)) != -1) {
                    buf.write(bloco, 0, n);
                    if (buf.size() > 750000) throw new Exception("Arquivo maior que 750 KB");
                }
                bytes = buf.toByteArray();
            }
            List<CodigoCheat> encontrados = lerCheats(new ByteArrayInputStream(bytes));
            if (encontrados.isEmpty()) throw new Exception("Nenhum cheat valido no arquivo .cht");
            File alvo = arquivoCheatExterno();
            if (!alvo.getParentFile().exists()) alvo.getParentFile().mkdirs();
            try (FileOutputStream out = new FileOutputStream(alvo)) { out.write(bytes); }
            boolean havia = !cheatsAtivos().isEmpty();
            salvarCheatsAtivos(Collections.emptySet());
            recarregarCheats();
            trocarBancoEReiniciarSeNecessario(havia);
            avisar(encontrados.size() + " cheats importados! Abra o menu Cheats.");
        } catch (Exception erro) {
            avisar("Falha na importacao: " + erro.getMessage());
        }
    }

    private void buscarCheatsOnline() {
        final EditText campo = new EditText(this);
        campo.setSingleLine(true);
        campo.setSelectAllOnFocus(true);
        campo.setText(nomeBuscaSugerido());
        campo.setHint("Exemplo: Sonic The Hedgehog");
        new AlertDialog.Builder(this)
            .setTitle("Pesquisar cheats por nome")
            .setMessage("Digite o nome original do jogo, nao o nome temporario " +
                "da ROM. Nome detectado: " +
                (tituloInterno == null || tituloInterno.isEmpty() ? "indisponivel" : tituloInterno) +
                ". Internet necessaria. Exemplo: Sonic The Hedgehog")
            .setView(campo)
            .setPositiveButton("Buscar", (d, w) -> {
                String busca = campo.getText().toString().trim();
                if (busca.isEmpty()) { avisar("Informe o nome de um jogo."); return; }
                consultarBancoLibretro(busca);
            })
            .setNegativeButton("Cancelar", null).show();
    }

    private void consultarBancoLibretro(String titulo) {
        avisar("Procurando: " + titulo);
        new Thread(() -> {
            // Arquivos reais usam regioes diferentes: (USA), (World), etc.
            // Os cheats SMS do Libretro usam regioes diferentes dos Mega Drive.
            // Ex.: Sonic The Hedgehog (USA, Europe, Brazil).cht.
            String[] sufixos = sistemaMaster ? new String[]{
                " (USA, Europe, Brazil)", " (Europe, Brazil)",
                " (USA, Europe)", " (USA)", " (World)",
                " (Europe)", " (Brazil)", " (Japan)", " (USA, Brazil)",
                " (USA, Europe, Brazil) (Action Replay)",
                " (USA, Europe, Brazil) (Game Genie)",
                " (Europe, Brazil) (Action Replay)",
                " (Europe, Brazil) (Game Genie)",
                " (USA, Europe) (Action Replay)",
                " (USA, Europe) (Game Genie)",
                " (USA) (Action Replay)", " (USA) (Game Genie)",
                " (World) (Action Replay)", " (World) (Game Genie)",
                " (Europe) (Action Replay)", " (Europe) (Game Genie)",
                " (Japan) (Action Replay)", " (Japan) (Game Genie)",
                ""
            } : new String[]{
                " (USA)", " (World)", " (USA, Europe)",
                " (USA, Europe, Japan)", " (USA) (Action Replay)",
                " (USA) (Game Genie)", " (World) (Action Replay)",
                " (World) (Game Genie)", " (USA, Europe) (Game Genie)",
                " (USA, Europe) (Action Replay)", " (Europe)", " (Japan)", ""};
            String tituloLimpo = titulo.replaceFirst("(?i)\\.cht$", "").trim();
            // Se usuario informou nome exato com regiao, tente ele primeiro.
            java.util.LinkedHashSet<String> candidatos = new java.util.LinkedHashSet<>();
            if (tituloLimpo.contains("(")) candidatos.add(tituloLimpo + ".cht");
            String nomeBase = tituloLimpo.replaceAll("\\s*\\([^)]*\\)", "").trim();
            for (String sufixo : sufixos) candidatos.add(nomeBase + sufixo + ".cht");
            int status404 = 0;
            String falhaRede = null;
            for (String arquivoNome : candidatos) {
                HttpURLConnection c = null;
                try {
                    String caminho = "https://raw.githubusercontent.com/libretro/libretro-database/master/cht/" +
                        (sistemaMaster ? "Sega%20-%20Master%20System%20-%20Mark%20III/" :
                            "Sega%20-%20Mega%20Drive%20-%20Genesis/");
                    String arquivoUrl = URLEncoder.encode(arquivoNome, "UTF-8").replace("+", "%20");
                    c = (HttpURLConnection) new URL(caminho + arquivoUrl).openConnection();
                    c.setConnectTimeout(5000);
                    c.setReadTimeout(7000);
                    c.setRequestProperty("User-Agent", "KikoVideoAulas/16 Android");
                    int status = c.getResponseCode();
                    if (status == 404) { status404++; continue; }
                    if (status != 200) {
                        falhaRede = "Resposta HTTP " + status;
                        break;
                    }
                    byte[] arquivo;
                    try (InputStream entrada = c.getInputStream();
                         ByteArrayOutputStream out = new ByteArrayOutputStream()) {
                        byte[] buffer = new byte[8192]; int n;
                        while ((n = entrada.read(buffer)) != -1) {
                            out.write(buffer, 0, n);
                            if (out.size() > 750000) throw new Exception("Arquivo muito grande");
                        }
                        arquivo = out.toByteArray();
                    }
                    List<CodigoCheat> selecionados = lerCheats(new ByteArrayInputStream(arquivo));
                    if (selecionados.isEmpty()) continue;
                    File dest = arquivoCheatExterno();
                    if (!dest.getParentFile().exists()) dest.getParentFile().mkdirs();
                    try (FileOutputStream saida = new FileOutputStream(dest)) { saida.write(arquivo); }
                    final boolean havia = !cheatsAtivos().isEmpty();
                    salvarCheatsAtivos(Collections.emptySet());
                            final int quantidade = selecionados.size();
                    runOnUiThread(() -> {
                        recarregarCheats();
                        trocarBancoEReiniciarSeNecessario(havia);
                        avisar(quantidade + " cheats encontrados! Selecione os desejados.");
                        abrirMenuCheats();
                    });
                    return;
                } catch (java.io.IOException ex) {
                    Log.w(TAG, "Rede: " + arquivoNome, ex);
                    falhaRede = ex.getClass().getSimpleName() + ": " + ex.getMessage();
                    break;
                } catch (Exception ex) {
                    Log.w(TAG, "Cheats invalidos: " + arquivoNome, ex);
                } finally {
                    if (c != null) c.disconnect();
                }
            }
            final String resultado = falhaRede == null
                ? "Nao localizei .cht para: " + titulo + ". Tente outro titulo ou importe um arquivo."
                : "Nao consegui acessar o banco online: " + falhaRede +
                    ". Confira sua internet e tente novamente.";
            runOnUiThread(() -> new AlertDialog.Builder(this)
                .setTitle("Resultado da busca")
                .setMessage(resultado)
                .setPositiveButton("OK", null).show());
        }, "KikoBuscaCheatsV16").start();
    }

    // So enviamos DOWN ou UP quando o estado combinado realmente muda.
    // Assim B virtual + B fisico nao se anulam, e Y+B funciona ao mesmo tempo.
    private void sincronizarComandos() {
        Set<Integer> juntos = new HashSet<>(virtuaisAtivos);
        juntos.addAll(fisicosAtivos);
        juntos.addAll(analogicosAtivos);
        if (!pronto || retro == null) {
            comandosEnviados.clear();
            return;
        }
        for (Integer codigo : new HashSet<>(comandosEnviados)) {
            if (!juntos.contains(codigo)) {
                enviarCodigo(codigo, false);
            }
        }
        for (Integer codigo : juntos) {
            if (!comandosEnviados.contains(codigo)) {
                enviarCodigo(codigo, true);
            }
        }
        comandosEnviados.clear();
        comandosEnviados.addAll(juntos);
    }

    private void enviarCodigo(int codigo, boolean pressionar) {
        try {
            retro.sendKeyEvent(
                pressionar ? KeyEvent.ACTION_DOWN : KeyEvent.ACTION_UP,
                codigo, 0);
        } catch (RuntimeException erro) {
            Log.e(TAG, "Erro ao enviar comando " + codigo, erro);
        }
    }

    private void alternarVirtuais() {
        mostrarVirtuais = !mostrarVirtuais;
        preferenciasControle.edit().putBoolean("mostrar_botoes", mostrarVirtuais).apply();
        if (controles != null) {
            controles.soltarTodos();
            controles.redesenhar();
        }
        avisar(mostrarVirtuais ? "Controles na tela visiveis" :
            "Controles ocultos. O botao MENU permanece visivel.");
    }

    private boolean ehTeclaDeControle(int codigo, KeyEvent e) {
        if (e.isFromSource(InputDevice.SOURCE_GAMEPAD) ||
            e.isFromSource(InputDevice.SOURCE_JOYSTICK) ||
            e.isFromSource(InputDevice.SOURCE_DPAD)) return true;
        if (codigo >= KeyEvent.KEYCODE_BUTTON_A &&
            codigo <= KeyEvent.KEYCODE_BUTTON_16) return true;
        return codigo == KeyEvent.KEYCODE_DPAD_UP ||
            codigo == KeyEvent.KEYCODE_DPAD_DOWN ||
            codigo == KeyEvent.KEYCODE_DPAD_LEFT ||
            codigo == KeyEvent.KEYCODE_DPAD_RIGHT;
    }

    private int converterBotao(int recebido) {
        if (recebido == KeyEvent.KEYCODE_DPAD_UP ||
            recebido == KeyEvent.KEYCODE_DPAD_DOWN ||
            recebido == KeyEvent.KEYCODE_DPAD_LEFT ||
            recebido == KeyEvent.KEYCODE_DPAD_RIGHT) return recebido;
        if (preferenciasControle.getBoolean("mapeado", false)) {
            for (int i = 0; i < ACOES_SN.length; i++) {
                if (preferenciasControle.getInt("map_" + i, -1) == recebido)
                    return ACOES_SN[i];
            }
            return -1;
        }
        for (int codigo : ACOES_SN) {
            if (codigo == recebido) return codigo;
        }
        return -1;
    }

    // Recebe os eventos ANTES da GLRetroView, inclusive controles Bluetooth.
    @Override
    public boolean dispatchKeyEvent(KeyEvent event) {
        int origem = event.getKeyCode();
        if (!ehTeclaDeControle(origem, event)) return super.dispatchKeyEvent(event);
        int destino = converterBotao(origem);
        if (destino < 0) return super.dispatchKeyEvent(event);
        if (event.getAction() == KeyEvent.ACTION_DOWN) {
            if (event.getRepeatCount() == 0) {
                fisicosAtivos.add(destino);
                sincronizarComandos();
            }
            return true;
        }
        if (event.getAction() == KeyEvent.ACTION_UP) {
            fisicosAtivos.remove(destino);
            sincronizarComandos();
            return true;
        }
        return super.dispatchKeyEvent(event);
    }

    // D-pad por eixos HAT ou analogico esquerdo, comum nos Ipega.
    @Override
    public boolean dispatchGenericMotionEvent(MotionEvent evento) {
        if (evento.isFromSource(InputDevice.SOURCE_JOYSTICK) &&
            evento.getActionMasked() == MotionEvent.ACTION_MOVE) {
            final float limite = 0.50f;
            float x = evento.getAxisValue(MotionEvent.AXIS_X);
            float y = evento.getAxisValue(MotionEvent.AXIS_Y);
            float hx = evento.getAxisValue(MotionEvent.AXIS_HAT_X);
            float hy = evento.getAxisValue(MotionEvent.AXIS_HAT_Y);
            Set<Integer> direcoes = new HashSet<>();
            if (x < -limite || hx < -limite) direcoes.add(KeyEvent.KEYCODE_DPAD_LEFT);
            if (x > limite || hx > limite) direcoes.add(KeyEvent.KEYCODE_DPAD_RIGHT);
            if (y < -limite || hy < -limite) direcoes.add(KeyEvent.KEYCODE_DPAD_UP);
            if (y > limite || hy > limite) direcoes.add(KeyEvent.KEYCODE_DPAD_DOWN);
            analogicosAtivos.clear();
            analogicosAtivos.addAll(direcoes);
            sincronizarComandos();
            return true;
        }
        return super.dispatchGenericMotionEvent(evento);
    }

    private void configurarBluetooth() {
        final int[] capturados = new int[ACOES_SN.length];
        Arrays.fill(capturados, -1);
        final int[] indice = {0};
        AlertDialog dialogo = new AlertDialog.Builder(this)
            .setTitle("Configurar Bluetooth")
            .setMessage("Pressione no controle o botao A do Mega Drive.")
            .setNegativeButton("Cancelar", (d, w) -> {})
            .create();

        dialogo.setOnKeyListener((d, codigo, e) -> {
            if (codigo == KeyEvent.KEYCODE_BACK) {
                dialogo.dismiss();
                return true;
            }
            if (e.getAction() != KeyEvent.ACTION_DOWN || e.getRepeatCount() > 0)
                return true;
            if (!ehTeclaDeControle(codigo, e)) return false;
            for (int i = 0; i < indice[0]; i++) {
                if (capturados[i] == codigo) {
                    avisar("Esse botao ja foi utilizado. Escolha outro.");
                    return true;
                }
            }
            capturados[indice[0]] = codigo;
            indice[0]++;
            if (indice[0] < ACOES_SN.length) {
                dialogo.setMessage("Agora pressione o botao para " +
                    ROTULOS_SN[indice[0]] + ".");
            } else {
                SharedPreferences.Editor editor = preferenciasControle.edit();
                for (int i = 0; i < capturados.length; i++) {
                    editor.putInt("map_" + i, capturados[i]);
                }
                editor.putBoolean("mapeado", true).apply();
                fisicosAtivos.clear();
                analogicosAtivos.clear();
                sincronizarComandos();
                dialogo.dismiss();
                avisar("Configuracao Bluetooth salva!");
            }
            return true;
        });
        dialogo.show();
    }

    private void restaurarBluetooth() {
        preferenciasControle.edit().putBoolean("mapeado", false).apply();
        fisicosAtivos.clear();
        analogicosAtivos.clear();
        sincronizarComandos();
        avisar("Mapeamento Bluetooth original restaurado.");
    }

    private void mostrarDispositivos() {
        StringBuilder sb = new StringBuilder();
        for (int id : InputDevice.getDeviceIds()) {
            InputDevice device = InputDevice.getDevice(id);
            if (device == null) continue;
            if ((device.getSources() & InputDevice.SOURCE_GAMEPAD) == InputDevice.SOURCE_GAMEPAD ||
                (device.getSources() & InputDevice.SOURCE_JOYSTICK) == InputDevice.SOURCE_JOYSTICK) {
                if (sb.length() > 0) sb.append("\n");
                sb.append("• ").append(device.getName());
            }
        }
        if (sb.length() == 0) sb.append("Nenhum gamepad detectado. Verifique o modo Android HID do controle.");
        new AlertDialog.Builder(this)
            .setTitle("Controles encontrados")
            .setMessage(sb.toString())
            .setPositiveButton("OK", null).show();
    }

    private void alterarOpacidade(float nova) {
        opacidade = nova;
        if (controles != null) controles.redesenhar();
        avisar("Opacidade dos controles ajustada.");
    }

    private void reiniciar() {
        new AlertDialog.Builder(this).setTitle("Reiniciar jogo?")
            .setPositiveButton("Sim", (d, w) -> {
                try { if (retro != null) retro.reset(true); }
                catch (Exception e) { erro(e); }
            })
            .setNegativeButton("Nao", null).show();
    }

    private void salvar() {
        if (!pronto || retro == null) return;
        new Thread(() -> {
            try {
                byte[] dados = retro.serializeState(true);
                if (dados == null || dados.length == 0) throw new Exception("Save nao disponivel agora.");
                Files.write(estado.toPath(), dados);
                byte[] memoria = retro.serializeSRAM(true);
                if (memoria != null && memoria.length > 0) Files.write(sram.toPath(), memoria);
                runOnUiThread(() -> avisar("Jogo salvo!"));
            } catch (Exception e) {
                runOnUiThread(() -> erro(e));
            }
        }).start();
    }

    private void carregar() {
        if (!pronto || retro == null) return;
        if (!estado.isFile()) { avisar("Nenhum save deste jogo."); return; }
        new Thread(() -> {
            try {
                if (!retro.unserializeState(Files.readAllBytes(estado.toPath()), true)) {
                    throw new Exception("Save nao compativel.");
                }
                runOnUiThread(() -> avisar("Jogo carregado!"));
            } catch (Exception e) {
                runOnUiThread(() -> erro(e));
            }
        }).start();
    }

    private void avisar(String texto) {
        Toast.makeText(this, texto, Toast.LENGTH_LONG).show();
    }

    private void erro(Exception e) {
        Log.e(TAG, "Erro no emulador", e);
        avisar("Falha: " + e.getMessage());
    }

    private void confirmarSaida() {
        new AlertDialog.Builder(this).setTitle("Fechar jogo?")
            .setMessage("Salve sua partida antes de sair.")
            .setPositiveButton("Sair", (d, w) -> finish())
            .setNegativeButton("Continuar", null).show();
    }

    @Override
    protected void onPause() {
        // Libera os botoes ANTES da pausa do GLRetroView, evitando tecla presa.
        if (controles != null) controles.soltarTodos();
        fisicosAtivos.clear();
        analogicosAtivos.clear();
        sincronizarComandos();
        super.onPause();
    }

    @Override
    protected void onDestroy() {
        // O LifecycleObserver do GLRetroView destrói o core nativo em ON_DESTROY.
        // NAO chamar LibretroDroid.destroy() de novo: causaria double free.
        encerrandoEmulacao = true;
        pronto = false;
        filaCheats.removeCallbacksAndMessages(null);
        comandosEnviados.clear();
        virtuaisAtivos.clear();
        fisicosAtivos.clear();
        analogicosAtivos.clear();
        try {
            super.onDestroy();
        } finally {
            // So o dono da sessao libera o bloqueio, e somente depois do
            // ON_DESTROY que desliga o nucleo do GLRetroView.
            if (donoDaSessao) {
                SESSAO_ATIVA.set(false);
                donoDaSessao = false;
            }
            controles = null;
            raizEmulador = null;
            retro = null;
        }
    }

    @Override
    protected void onResume() {
        super.onResume();
        if (retro != null) esconderBarras();
    }

    @Override
    public void onWindowFocusChanged(boolean hasFocus) {
        super.onWindowFocusChanged(hasFocus);
        if (!hasFocus) {
            if (controles != null) controles.soltarTodos();
            fisicosAtivos.clear();
            analogicosAtivos.clear();
            sincronizarComandos();
        }
    }

    // Eventos reconhecidos de gamepad sao capturados em dispatchKeyEvent.
    // Os demais eventos seguem o fluxo normal do Android.

    @Override
    public void onBackPressed() {
        if (controles != null) controles.soltarTodos();
        confirmarSaida();
    }
}
