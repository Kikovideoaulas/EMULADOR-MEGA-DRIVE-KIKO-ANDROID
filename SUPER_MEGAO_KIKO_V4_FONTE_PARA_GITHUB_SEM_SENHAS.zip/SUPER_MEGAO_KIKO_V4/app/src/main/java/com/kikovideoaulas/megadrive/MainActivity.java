package com.kikovideoaulas.megadrive;

import android.app.Activity;
import android.app.AlertDialog;
import android.content.ClipData;
import android.content.Intent;
import android.content.ActivityNotFoundException;
import android.content.SharedPreferences;
import android.content.pm.ActivityInfo;
import android.database.Cursor;
import android.graphics.Color;
import android.graphics.Bitmap;
import android.graphics.BitmapFactory;
import android.graphics.Typeface;
import android.graphics.drawable.GradientDrawable;
import android.net.Uri;
import android.os.Bundle;
import android.provider.OpenableColumns;
import android.provider.DocumentsContract;
import android.provider.DocumentsContract.Document;
import android.view.inputmethod.InputMethodManager;
import android.content.Context;
import android.content.res.Configuration;
import android.text.Editable;
import android.text.TextWatcher;
import android.view.Gravity;
import android.view.View;
import android.widget.Button;
import android.widget.EditText;
import android.widget.FrameLayout;
import android.widget.ImageView;
import android.widget.LinearLayout;
import android.widget.ScrollView;
import android.widget.TextView;
import android.widget.Toast;
import org.json.JSONArray;
import org.json.JSONObject;
import java.util.ArrayList;
import java.util.Collections;
import java.util.Comparator;
import java.util.Locale;
import java.io.InputStream;
import java.io.IOException;
import java.io.File;
import java.io.FileOutputStream;
import java.io.OutputStream;
import java.util.HashSet;
import java.util.Set;

/**
 * Interface Mega Drive + Master System KIKO VIDEO AULAS em Java.
 * Usa LibretroDroid e Genesis Plus GX para Mega Drive e Master System.
 */
public class MainActivity extends Activity {

    private static final int PICK_ROMS = 200;
    private static final int PICK_FOLDER = 201;
    private static final String KEY_TREE = "pasta_roms_autorizada";
    private static final int PAGE_SIZE = 70;
    private static final String PREFS = "kiko_arquivo_roms";
    private static final String KEY_GAMES = "jogos";

    private static final int FUNDO = 0xFF090B12;
    private static final int MENU = 0xFF11151F;
    private static final int ROXO = 0xFF137AD9;
    private static final int TEXTO = Color.WHITE;
    private static final int CINZA = 0xFFA3AABD;

    private FrameLayout areaCentral;
    private LinearLayout[] botoesMenu = new LinearLayout[4];
    private ArrayList<Jogo> jogos = new ArrayList<>();
    private int paginaAtual = 0;
    private String termoBusca = "";
    private int limiteDaLista = PAGE_SIZE;
    // 0=todos, 1=Mega Drive, 2=Master System, 3=identificacao pendente.
    private int filtroConsole = RomConsoleDetector.CONFERIR;
    private static final int FILTRO_CONFERIR = 3;
    private volatile boolean buscandoPastas = false;
    private volatile boolean reexaminarPastas = false;
    private volatile boolean iniciandoJogo = false;

    private static class Jogo {
        String nome;
        String uri;
        boolean favorito;
        int console;
        boolean escolhidoManualmente;

        Jogo(String nome, String uri, boolean favorito) {
            this(nome, uri, favorito, RomConsoleDetector.pelaExtensao(nome), false);
        }

        Jogo(String nome, String uri, boolean favorito, int console, boolean manual) {
            this.nome = nome;
            this.uri = uri;
            this.favorito = favorito;
            this.console = console;
            this.escolhidoManualmente = manual;
        }
    }

    private String nomeConsole(int console) {
        if (console == RomConsoleDetector.MEGA_DRIVE) return "MEGA DRIVE";
        if (console == RomConsoleDetector.MASTER_SYSTEM) return "MASTER SYSTEM";
        return "A CONFERIR";
    }

    private int corConsole(int console) {
        if (console == RomConsoleDetector.MEGA_DRIVE) return 0xFF82C6FF;
        if (console == RomConsoleDetector.MASTER_SYSTEM) return 0xFFFFC56F;
        return 0xFFD8DAE3;
    }

    // ROMs BIN e ZIP podem pertencer aos dois consoles. Ler o cabecalho evita
    // confundir Master System com Mega Drive pela extensao do arquivo.
    private int identificarRom(String nome, String endereco) {
        int tipo = RomConsoleDetector.pelaExtensao(nome);
        if (!RomConsoleDetector.exigeLeitura(nome)) return tipo;
        try (InputStream entrada = endereco.startsWith("assetrom:")
                ? getAssets().open(endereco.substring("assetrom:".length()))
                : getContentResolver().openInputStream(Uri.parse(endereco))) {
            return RomConsoleDetector.identificar(nome, entrada);
        } catch (Exception e) {
            return tipo; // Sem acesso: mostrar A CONFERIR, nunca adivinhar.
        }
    }

    @Override
    protected void onCreate(Bundle savedInstanceState) {
        super.onCreate(savedInstanceState);
        // A tela horizontal ja e definida no AndroidManifest.xml, antes do onCreate.
        // Nao solicitar novamente: evita recriacao na abertura.
        getWindow().setStatusBarColor(FUNDO);
        getWindow().setNavigationBarColor(FUNDO);
        recuperarJogos();
        montarTela();
        // Biblioteca indexada automaticamente; nao copia as 1.900 ROMs para a memoria.
        atualizarPastasAutomaticamente();
    }

    private int dp(float tamanho) {
        return Math.round(tamanho * getResources().getDisplayMetrics().density);
    }

    private TextView texto(String valor, float tamanho, int cor, boolean negrito) {
        TextView t = new TextView(this);
        t.setText(valor);
        t.setTextSize(tamanho);
        t.setTextColor(cor);
        if (negrito) t.setTypeface(Typeface.DEFAULT, Typeface.BOLD);
        t.setGravity(Gravity.CENTER_VERTICAL);
        return t;
    }

    private GradientDrawable fundo(int cor, float raio) {
        GradientDrawable g = new GradientDrawable();
        g.setColor(cor);
        g.setCornerRadius(dp(raio));
        return g;
    }

    private LinearLayout vertical() {
        LinearLayout l = new LinearLayout(this);
        l.setOrientation(LinearLayout.VERTICAL);
        return l;
    }

    private LinearLayout horizontal() {
        LinearLayout l = new LinearLayout(this);
        l.setOrientation(LinearLayout.HORIZONTAL);
        l.setGravity(Gravity.CENTER_VERTICAL);
        return l;
    }

    private Button botao(String titulo) {
        Button b = new Button(this);
        b.setAllCaps(false);
        b.setText(titulo);
        b.setTextSize(14);
        b.setTextColor(TEXTO);
        b.setBackground(fundo(ROXO, 12));
        b.setPadding(dp(12), 0, dp(12), 0);
        return b;
    }

    private void montarTela() {
        LinearLayout tela = vertical();
        tela.setBackgroundColor(FUNDO);
        setContentView(tela);

        LinearLayout topo = horizontal();
        topo.setBackgroundColor(MENU);
        topo.setPadding(dp(18), 0, dp(16), 0);
        tela.addView(topo, new LinearLayout.LayoutParams(-1, dp(62)));

        TextView icone = texto("🎮", 27, TEXTO, false);
        topo.addView(icone);

        LinearLayout titulos = vertical();
        titulos.setPadding(dp(14), 0, 0, 0);
        titulos.addView(texto("SUPER MEGAO KIKO", 19, TEXTO, true));
        titulos.addView(texto("Jogos Clássicos Sempre com Você", 12, CINZA, false));
        topo.addView(titulos);

        // V21: celular em pe = menu compacto; deitado = menu lateral original.
        // O sensor controla a orientacao, sem forcar girar ao abrir o app.
        boolean emPe = getResources().getConfiguration().orientation
                == Configuration.ORIENTATION_PORTRAIT;
        if (emPe) {
            LinearLayout navegacao = horizontal();
            navegacao.setBackgroundColor(MENU);
            navegacao.setPadding(dp(4), dp(4), dp(4), dp(4));
            tela.addView(navegacao, new LinearLayout.LayoutParams(-1, dp(70)));

            adicionarItemCompacto(navegacao, "⌂", "Início", 0);
            adicionarItemCompacto(navegacao, "🎮", "Jogos", 1);
            adicionarItemCompacto(navegacao, "♥", "Favoritos", 2);
            adicionarItemCompacto(navegacao, "⚙", "Config.", 3);

            areaCentral = new FrameLayout(this);
            areaCentral.setBackgroundColor(Color.BLACK);
            tela.addView(areaCentral, new LinearLayout.LayoutParams(-1, 0, 1));
        } else {
            // Layout horizontal aprovado na V20: nenhuma mudanca visual.
            LinearLayout corpo = horizontal();
            tela.addView(corpo, new LinearLayout.LayoutParams(-1, 0, 1));

            LinearLayout lateral = vertical();
            lateral.setPadding(dp(6), dp(16), dp(6), dp(6));
            lateral.setBackgroundColor(MENU);
            corpo.addView(lateral, new LinearLayout.LayoutParams(dp(174), -1));

            adicionarItem(lateral, "⌂", "Início", 0);
            adicionarItem(lateral, "🎮", "Jogos", 1);
            adicionarItem(lateral, "♥", "Favoritos", 2);
            adicionarItem(lateral, "⚙", "Configurações", 3);

            areaCentral = new FrameLayout(this);
            areaCentral.setBackgroundColor(Color.BLACK);
            corpo.addView(areaCentral, new LinearLayout.LayoutParams(0, -1, 1));
        }
        // Mantem a pagina e o filtro ao mudar de orientacao.
        mostrarPagina(paginaAtual);
    }

    private void adicionarItem(LinearLayout lateral, String simbolo, String titulo, final int pagina) {
        LinearLayout linha = horizontal();
        linha.setPadding(dp(10), 0, dp(6), 0);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, dp(58));
        lp.bottomMargin = dp(7);
        lateral.addView(linha, lp);

        TextView icon = texto(simbolo, 22, TEXTO, false);
        icon.setGravity(Gravity.CENTER);
        linha.addView(icon, new LinearLayout.LayoutParams(dp(34), -1));

        TextView label = texto(titulo, 16, TEXTO, false);
        label.setPadding(dp(8), 0, 0, 0);
        linha.addView(label);

        linha.setOnClickListener(v -> mostrarPagina(pagina));
        botoesMenu[pagina] = linha;
    }

    // Menu adaptado para a tela em pe, preservando as mesmas quatro funcoes.
    private void adicionarItemCompacto(LinearLayout barra, String simbolo,
                                       String titulo, final int pagina) {
        LinearLayout item = vertical();
        item.setGravity(Gravity.CENTER);
        LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(0, -1, 1);
        lp.leftMargin = dp(2);
        lp.rightMargin = dp(2);
        barra.addView(item, lp);

        TextView icone = texto(simbolo, 23, TEXTO, false);
        icone.setGravity(Gravity.CENTER);
        item.addView(icone, new LinearLayout.LayoutParams(-1, dp(31)));
        TextView legenda = texto(titulo, 12, TEXTO, false);
        legenda.setGravity(Gravity.CENTER);
        legenda.setSingleLine(true);
        item.addView(legenda, new LinearLayout.LayoutParams(-1, dp(22)));

        item.setOnClickListener(v -> mostrarPagina(pagina));
        botoesMenu[pagina] = item;
    }

    @Override
    public void onConfigurationChanged(Configuration novaConfiguracao) {
        super.onConfigurationChanged(novaConfiguracao);
        // Sem recriar Activity, favoritos, lista e pesquisas continuam intactos.
        if (!isFinishing() && !isDestroyed()) montarTela();
    }

    private void mostrarPagina(int pagina) {
        paginaAtual = pagina;
        for (int i = 0; i < botoesMenu.length; i++) {
            if (botoesMenu[i] != null) {
                if (i == pagina) {
                    botoesMenu[i].setBackground(fundo(0xFF282D3C, 12));
                } else {
                    botoesMenu[i].setBackgroundColor(Color.TRANSPARENT);
                }
            }
        }
        areaCentral.removeAllViews();
        if (pagina == 0) exibirInicio();
        else if (pagina == 1) exibirBiblioteca(false);
        else if (pagina == 2) exibirBiblioteca(true);
        else exibirConfiguracoes();
    }

    private void exibirInicio() {
        // O banner vem de assets: nao depende da classe R.drawable gerada pelo Gradle.
        ImageView banner = new ImageView(this);
        banner.setScaleType(ImageView.ScaleType.FIT_CENTER);
        banner.setContentDescription("Mega Drive e lobo KIKO VIDEO AULAS em vermelho");

        try (InputStream arquivo = getAssets().open("kiko_banner.png")) {
            Bitmap imagem = BitmapFactory.decodeStream(arquivo);
            if (imagem == null) {
                throw new IOException("A imagem nao pode ser decodificada");
            }
            banner.setImageBitmap(imagem);
            areaCentral.addView(banner, new FrameLayout.LayoutParams(-1, -1));
            banner.setOnClickListener(v -> mostrarPagina(1));
        } catch (IOException e) {
            // Sem imagem, a tela continua abrindo e permite acessar os jogos.
            TextView titulo = texto("SUPER MEGAO KIKO\nMEGA DRIVE + MASTER SYSTEM", 26, TEXTO, true);
            titulo.setGravity(Gravity.CENTER);
            areaCentral.addView(titulo, new FrameLayout.LayoutParams(-1, -1));
            titulo.setOnClickListener(v -> mostrarPagina(1));
        }
    }

    private void exibirBiblioteca(boolean somenteFavoritos) {
        LinearLayout pagina = vertical();
        pagina.setPadding(dp(20), dp(12), dp(20), dp(12));
        areaCentral.addView(pagina, new FrameLayout.LayoutParams(-1, -1));

        LinearLayout faixa = horizontal();
        pagina.addView(faixa, new LinearLayout.LayoutParams(-1, dp(54)));

        TextView titulo = texto(somenteFavoritos ? "Favoritos" : "Jogos (" + jogos.size() + ")", 20, TEXTO, true);
        faixa.addView(titulo, new LinearLayout.LayoutParams(0, -1, 1));

        Button pasta = botao("Pasta ROMs");
        faixa.addView(pasta, new LinearLayout.LayoutParams(dp(122), dp(43)));
        pasta.setOnClickListener(v -> escolherPasta());


        EditText busca = new EditText(this);
        busca.setSingleLine(true);
        busca.setTextSize(16);
        busca.setTextColor(TEXTO);
        busca.setHintTextColor(CINZA);
        busca.setHint("Pesquisar jogos...");
        busca.setPadding(dp(14), 0, dp(14), 0);
        busca.setBackground(fundo(0xFF222533, 10));
        LinearLayout.LayoutParams lpBusca = new LinearLayout.LayoutParams(-1, dp(43));
        lpBusca.topMargin = dp(5);
        lpBusca.bottomMargin = dp(9);
        LinearLayout faixaBusca = horizontal();
        pagina.addView(faixaBusca, lpBusca);
        faixaBusca.addView(busca, new LinearLayout.LayoutParams(0, -1, 1));
        Button buscar = botao("Buscar");
        LinearLayout.LayoutParams pb = new LinearLayout.LayoutParams(dp(88), -1);
        pb.leftMargin = dp(7);
        faixaBusca.addView(buscar, pb);
        buscar.setOnClickListener(v -> {
            busca.requestFocus();
            InputMethodManager teclado = (InputMethodManager)
                    getSystemService(Context.INPUT_METHOD_SERVICE);
            if (teclado != null) teclado.showSoftInput(busca, InputMethodManager.SHOW_IMPLICIT);
        });
        busca.setText(termoBusca);

        ScrollView rolagem = new ScrollView(this);
        rolagem.setFillViewport(true);
        LinearLayout lista = vertical();
        rolagem.addView(lista);
        montarFiltrosConsole(pagina, lista, somenteFavoritos);
        pagina.addView(rolagem, new LinearLayout.LayoutParams(-1, 0, 1));
        preencherLista(lista, somenteFavoritos, termoBusca);

        busca.addTextChangedListener(new TextWatcher() {
            @Override public void beforeTextChanged(CharSequence s, int start, int count, int after) {}
            @Override public void onTextChanged(CharSequence s, int start, int before, int count) {
                termoBusca = s.toString();
                limiteDaLista = PAGE_SIZE;
                preencherLista(lista, somenteFavoritos, termoBusca);
            }
            @Override public void afterTextChanged(Editable s) {}
        });
    }

    private int contarConsole(boolean somenteFavoritos, int tipo) {
        int n = 0;
        for (Jogo jogo : jogos) {
            if (somenteFavoritos && !jogo.favorito) continue;
            if (tipo == 0 || (tipo == FILTRO_CONFERIR
                    ? jogo.console == RomConsoleDetector.CONFERIR
                    : jogo.console == tipo)) n++;
        }
        return n;
    }

    private void montarFiltrosConsole(LinearLayout pagina, LinearLayout lista, boolean favoritos) {
        TextView explicacao = texto("SEPARAR JOGOS POR CONSOLE", 11, CINZA, true);
        LinearLayout.LayoutParams subLp = new LinearLayout.LayoutParams(-1, dp(24));
        pagina.addView(explicacao, subLp);
        // Barra rolavel: os nomes nao ficam cortados no celular em pe.
        android.widget.HorizontalScrollView rolagem = new android.widget.HorizontalScrollView(this);
        rolagem.setHorizontalScrollBarEnabled(false);
        LinearLayout faixa = horizontal();
        rolagem.addView(faixa);
        pagina.addView(rolagem, new LinearLayout.LayoutParams(-1, dp(48)));

        int[] tipos = {0, RomConsoleDetector.MEGA_DRIVE,
                RomConsoleDetector.MASTER_SYSTEM, FILTRO_CONFERIR};
        String[] nomes = {"TODOS", "MEGA DRIVE", "MASTER SYSTEM", "A CONFERIR"};
        for (int i = 0; i < tipos.length; i++) {
            final int tipo = tipos[i];
            TextView opcao = texto(nomes[i] + "  " + contarConsole(favoritos, tipo),
                    12, tipo == 0 ? TEXTO : corConsole(tipo), true);
            opcao.setGravity(Gravity.CENTER);
            opcao.setPadding(dp(14), 0, dp(14), 0);
            opcao.setBackground(fundo(filtroConsole == tipo ? 0xFF334B68 : 0xFF1D2330, 12));
            LinearLayout.LayoutParams itemLp = new LinearLayout.LayoutParams(-2, dp(38));
            itemLp.rightMargin = dp(8);
            faixa.addView(opcao, itemLp);
            opcao.setOnClickListener(v -> {
                filtroConsole = tipo;
                limiteDaLista = PAGE_SIZE;
                // Reconstruir a barra destaca o filtro selecionado e atualiza totais.
                mostrarPagina(paginaAtual);
            });
        }
    }

    private void preencherLista(LinearLayout lista, boolean somenteFavoritos, String busca) {
        lista.removeAllViews();
        String pesquisa = busca == null ? "" : busca.toLowerCase(Locale.ROOT).trim();
        ArrayList<Jogo> copia = new ArrayList<>(jogos);
        Collections.sort(copia, Comparator.comparing(j -> j.nome.toLowerCase(Locale.ROOT)));
        int exibidos = 0;
        int totalFiltrado = 0;

        for (Jogo jogo : copia) {
            if (somenteFavoritos && !jogo.favorito) continue;
            if (filtroConsole == FILTRO_CONFERIR) {
                if (jogo.console != RomConsoleDetector.CONFERIR) continue;
            } else if (filtroConsole != 0 && jogo.console != filtroConsole) continue;
            if (!jogo.nome.toLowerCase(Locale.ROOT).contains(pesquisa)) continue;
            totalFiltrado++;
            if (exibidos >= limiteDaLista) continue;
            exibidos++;

            LinearLayout linha = horizontal();
            linha.setBackground(fundo(0xFF1A1D29, 11));
            linha.setPadding(dp(12), 0, dp(12), 0);
            LinearLayout.LayoutParams lp = new LinearLayout.LayoutParams(-1, dp(74));
            lp.bottomMargin = dp(7);
            lista.addView(linha, lp);

            TextView icone = texto(jogo.console == RomConsoleDetector.MEGA_DRIVE ? "MD" :
                    jogo.console == RomConsoleDetector.MASTER_SYSTEM ? "MS" : "?",
                    14, corConsole(jogo.console), true);
            icone.setGravity(Gravity.CENTER);
            linha.addView(icone, new LinearLayout.LayoutParams(dp(36), -1));
            icone.setOnClickListener(v -> escolherConsole(jogo));

            LinearLayout informacoes = vertical();
            informacoes.setGravity(Gravity.CENTER_VERTICAL);
            linha.addView(informacoes, new LinearLayout.LayoutParams(0, -1, 1));
            TextView nome = texto(jogo.nome, 15, TEXTO, true);
            nome.setSingleLine(true);
            nome.setEllipsize(android.text.TextUtils.TruncateAt.END);
            informacoes.addView(nome, new LinearLayout.LayoutParams(-1, dp(27)));
            nome.setOnClickListener(v -> detalhesDoJogo(jogo));
            TextView selo = texto("● " + nomeConsole(jogo.console) +
                    (jogo.escolhidoManualmente ? "  ✎" : ""),
                    12, corConsole(jogo.console), true);
            selo.setContentDescription("Console: " + nomeConsole(jogo.console)
                    + ". Toque para corrigir a identificacao.");
            informacoes.addView(selo, new LinearLayout.LayoutParams(-1, dp(26)));
            selo.setOnClickListener(v -> escolherConsole(jogo));

            TextView favoritar = texto(jogo.favorito ? "★" : "☆", 29,
                    jogo.favorito ? 0xFFFFD45B : CINZA, false);
            favoritar.setGravity(Gravity.CENTER);
            linha.addView(favoritar, new LinearLayout.LayoutParams(dp(43), -1));
            favoritar.setOnClickListener(v -> {
                jogo.favorito = !jogo.favorito;
                salvarJogos();
                preencherLista(lista, somenteFavoritos, termoBusca);
            });

            Button abrir = botao("Abrir");
            linha.addView(abrir, new LinearLayout.LayoutParams(dp(73), dp(42)));
            abrir.setOnClickListener(v -> detalhesDoJogo(jogo));
        }

        if (totalFiltrado > exibidos) {
            Button mais = botao("Mostrar mais jogos (" + (totalFiltrado - exibidos) + " restantes)");
            lista.addView(mais, new LinearLayout.LayoutParams(-1, dp(48)));
            mais.setOnClickListener(v -> {
                limiteDaLista += PAGE_SIZE;
                preencherLista(lista, somenteFavoritos, termoBusca);
            });
        }

        if (exibidos == 0) {
            TextView vazio = texto(
                jogos.isEmpty() ? "Nenhuma ROM encontrada. Toque em Pasta ROMs e selecione a pasta com seus jogos."
                  : "Nenhum jogo encontrado nesta seção.",
                17, CINZA, false
            );
            vazio.setGravity(Gravity.CENTER);
            vazio.setPadding(dp(16), dp(30), dp(16), dp(30));
            lista.addView(vazio);
        }
    }

    private void selecionarArquivos() {
        Intent intent = new Intent(Intent.ACTION_OPEN_DOCUMENT);
        intent.addCategory(Intent.CATEGORY_OPENABLE);
        intent.setType("*/*");
        intent.putExtra(Intent.EXTRA_ALLOW_MULTIPLE, true);
        intent.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION);
        intent.addFlags(Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION);
        try {
            startActivityForResult(intent, PICK_ROMS);
        } catch (ActivityNotFoundException e) {
            Toast.makeText(this, "Seletor de arquivos indisponível", Toast.LENGTH_LONG).show();
        }
    }

    @Override
    protected void onActivityResult(int requestCode, int resultCode, Intent data) {
        super.onActivityResult(requestCode, resultCode, data);
        if (resultCode != RESULT_OK || data == null) return;
        if (requestCode == PICK_FOLDER) {
            Uri pasta = data.getData();
            if (pasta == null) return;
            try {
                getContentResolver().takePersistableUriPermission(
                    pasta, Intent.FLAG_GRANT_READ_URI_PERMISSION);
                getSharedPreferences(PREFS, MODE_PRIVATE).edit()
                    .putString(KEY_TREE, pasta.toString()).apply();
                atualizarPastasAutomaticamente();
            } catch (Exception e) {
                Toast.makeText(this, "Não foi possível autorizar a pasta: " +
                    e.getMessage(), Toast.LENGTH_LONG).show();
            }
            return;
        }
        if (requestCode != PICK_ROMS) return;
        int adicionados = 0;
        ClipData clips = data.getClipData();
        if (clips != null) {
            for (int i = 0; i < clips.getItemCount(); i++) {
                if (registrarRom(clips.getItemAt(i).getUri())) adicionados++;
            }
        } else if (data.getData() != null) {
            if (registrarRom(data.getData())) adicionados++;
        }
        salvarJogos();
        termoBusca = "";
        mostrarPagina(1);
        Toast.makeText(this, "ROMs adicionadas: " + adicionados, Toast.LENGTH_LONG).show();
    }

    private String obterNome(Uri uri) {
        String nome = null;
        try (Cursor cursor = getContentResolver().query(uri,
                new String[]{OpenableColumns.DISPLAY_NAME}, null, null, null)) {
            if (cursor != null && cursor.moveToFirst()) nome = cursor.getString(0);
        } catch (Exception ignored) {}
        if (nome == null || nome.trim().isEmpty()) nome = uri.getLastPathSegment();
        return nome == null ? "ROM sem nome" : nome;
    }

    private boolean registrarRom(Uri uri) {
        if (uri == null) return false;
        String nome = obterNome(uri);
        String lower = nome.toLowerCase(Locale.ROOT);
        if (!(eRom(nome))) return false;
        String endereco = uri.toString();
        for (Jogo j : jogos) if (j.uri.equals(endereco)) return false;
        try {
            getContentResolver().takePersistableUriPermission(uri, Intent.FLAG_GRANT_READ_URI_PERMISSION);
        } catch (Exception ignored) {
            // Alguns provedores não permitem acesso permanente.
        }
        // Arquivos BIN/ZIP sao identificados em segundo plano para nao travar a tela.
        Jogo novo = new Jogo(nome, endereco, false);
        jogos.add(novo);
        if (RomConsoleDetector.exigeLeitura(nome)) {
            new Thread(() -> {
                int console = identificarRom(nome, endereco);
                runOnUiThread(() -> {
                    if (isFinishing() || isDestroyed() || novo.escolhidoManualmente
                            || !jogos.contains(novo)) return;
                    if (novo.console != console) {
                        novo.console = console;
                        salvarJogos();
                        if (paginaAtual == 1 || paginaAtual == 2) mostrarPagina(paginaAtual);
                    }
                });
            }, "identificar-rom-sega").start();
        }
        return true;
    }

    // Permite corrigir dumps BIN/ZIP sem assinatura de console legivel.
    // A escolha fica gravada em favoritos/biblioteca e vale na hora de abrir.
    private void escolherConsole(Jogo jogo) {
        new AlertDialog.Builder(this)
            .setTitle("Identificar console")
            .setMessage(jogo.nome + "\n\nIdentificacao atual: " + nomeConsole(jogo.console)
                    + "\n\nSelecione o console correto se a deteccao automatica falhar.")
            .setItems(new String[]{"MEGA DRIVE", "MASTER SYSTEM", "DETECTAR AUTOMATICAMENTE"},
                (d, qual) -> {
                    if (qual == 2) {
                        jogo.escolhidoManualmente = false;
                        jogo.console = RomConsoleDetector.pelaExtensao(jogo.nome);
                        salvarJogos();
                        mostrarPagina(paginaAtual);
                        new Thread(() -> {
                            int detectado = identificarRom(jogo.nome, jogo.uri);
                            runOnUiThread(() -> {
                                if (isFinishing() || isDestroyed()
                                        || jogo.escolhidoManualmente) return;
                                jogo.console = detectado;
                                salvarJogos();
                                mostrarPagina(paginaAtual);
                            });
                        }, "redetectar-sega").start();
                    } else {
                        jogo.console = qual == 0 ? RomConsoleDetector.MEGA_DRIVE
                                : RomConsoleDetector.MASTER_SYSTEM;
                        jogo.escolhidoManualmente = true;
                        salvarJogos();
                        mostrarPagina(paginaAtual);
                    }
                })
            .setNegativeButton("Cancelar", null)
            .show();
    }

    private void detalhesDoJogo(Jogo jogo) {
        new AlertDialog.Builder(this)
            .setTitle(jogo.nome)
            .setMessage("CONSOLE: " + nomeConsole(jogo.console)
                + "\n\nO emulador usa Genesis Plus GX. Para corrigir a identificacao,"
                + " toque no selo MD, MS ou ? ao lado do jogo.\n\n"
                + "Formatos: .md, .gen, .bin, .smd, .sms e .zip.")
            .setPositiveButton("Jogar agora", (d, w) -> iniciarJogo(jogo))
            .setNeutralButton("Remover da lista", (d, w) -> confirmarRemocao(jogo))
            .setNegativeButton("Cancelar", null)
            .show();
    }

    private void iniciarJogo(Jogo jogo) {
        // Evita dois toques abrirem duas Activities com o mesmo core nativo.
        if (iniciandoJogo) return;
        iniciandoJogo = true;
        final AlertDialog progresso = new AlertDialog.Builder(this)
            .setTitle("Preparando jogo")
            .setMessage("Copiando a ROM para iniciar a emulação...")
            .setCancelable(false)
            .create();
        progresso.show();
        new Thread(() -> {
            try {
                Uri origem = Uri.parse(jogo.uri);
                if (jogo.uri.startsWith("assetrom:")) {
                    origem = prepararRomEmAssets(jogo.uri.substring("assetrom:".length()));
                }
                java.io.File arquivo = RomInstaller.preparar(this, origem, jogo.nome,
                        jogo.escolhidoManualmente ? jogo.console : RomConsoleDetector.CONFERIR);
                runOnUiThread(() -> {
                    if (isFinishing() || isDestroyed()) return;
                    progresso.dismiss();
                    iniciandoJogo = false;
                    Intent intent = new Intent(this, EmulatorActivity.class);
                    intent.putExtra(EmulatorActivity.EXTRA_CAMINHO, arquivo.getAbsolutePath());
                    intent.putExtra(EmulatorActivity.EXTRA_NOME, jogo.nome);
                    startActivity(intent);
                });
            } catch (Exception e) {
                runOnUiThread(() -> {
                    if (isFinishing() || isDestroyed()) return;
                    progresso.dismiss();
                    iniciandoJogo = false;
                    new AlertDialog.Builder(this)
                        .setTitle("Não foi possível abrir a ROM")
                        .setMessage(e.getMessage())
                        .setPositiveButton("OK", null)
                        .show();
                });
            }
        }).start();
    }

    private void confirmarRemocao(Jogo jogo) {
        new AlertDialog.Builder(this)
            .setTitle("Remover da biblioteca?")
            .setMessage("Isso não apaga o arquivo original do celular.")
            .setPositiveButton("Remover", (d, w) -> {
                jogos.remove(jogo);
                salvarJogos();
                mostrarPagina(paginaAtual);
            })
            .setNegativeButton("Cancelar", null)
            .show();
    }

    private void exibirConfiguracoes() {
        LinearLayout painel = vertical();
        painel.setPadding(dp(25), dp(20), dp(25), dp(10));
        areaCentral.addView(painel, new FrameLayout.LayoutParams(-1, -1));
        painel.addView(texto("Configurações", 25, TEXTO, true));

        TextView descricao = texto("Mega Drive • Master System\n" +
                jogos.size() + " ROM(s) cadastrada(s)\n" +
                "Núcleo: Genesis Plus GX (licença não comercial).\n" +
                "Arquitetura: Android ARM64.\n" +
                "ROMs: MD, GEN, BIN, SMD, SMS e ZIP.\n" +
                "Pasta configurada: " + (getSharedPreferences(PREFS, MODE_PRIVATE)
                  .contains(KEY_TREE) ? "SIM" : "ainda nao selecionada") + "\n" +
                "Pasta automatica do app: Android/data/.../files/roms", 16, CINZA, false);
        descricao.setPadding(0, dp(14), 0, dp(20));
        painel.addView(descricao);

        Button apagar = botao("Limpar biblioteca");
        painel.addView(apagar, new LinearLayout.LayoutParams(dp(190), dp(48)));
        apagar.setOnClickListener(v -> {
            new AlertDialog.Builder(this)
                .setTitle("Limpar biblioteca?")
                .setMessage("Remove todos os jogos da lista e os favoritos, sem apagar os arquivos originais.")
                .setPositiveButton("Limpar", (d, w) -> {
                    jogos.clear();
                    salvarJogos();
                    mostrarPagina(3);
                })
                .setNegativeButton("Cancelar", null).show();
        });
    }


    // ===== KIKO V11: LEITURA AUTOMATICA DAS PASTAS =====
    // Sem permissao especial para acessar todo o armazenamento do celular.
    // O usuario autoriza UMA VEZ a pasta da distribuicao KIKO_Mega Drive e Master System/roms.
    private void escolherPasta() {
        Intent intento = new Intent(Intent.ACTION_OPEN_DOCUMENT_TREE);
        intento.addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION |
                Intent.FLAG_GRANT_PERSISTABLE_URI_PERMISSION |
                Intent.FLAG_GRANT_PREFIX_URI_PERMISSION);

        // Sugere Downloads como pasta inicial do seletor de arquivos.
        // O Android decide se respeita essa sugestao.
        // A pasta Downloads inteira nao pode ser autorizada no Android 11+:
        // selecione uma SUBPASTA, como Download/ROMs.
        Uri downloads = DocumentsContract.buildDocumentUri(
                "com.android.externalstorage.documents", "primary:Download");
        intento.putExtra(DocumentsContract.EXTRA_INITIAL_URI, downloads);

        try {
            startActivityForResult(intento, PICK_FOLDER);
        } catch (Exception e) {
            Toast.makeText(this,
                    "Não foi possível abrir o seletor de pastas.",
                    Toast.LENGTH_LONG).show();
        }
    }

    private boolean eRom(String nome) {
        String n = nome.toLowerCase(Locale.ROOT);
        return n.endsWith(".md") || n.endsWith(".gen") || n.endsWith(".bin") || n.endsWith(".smd") || n.endsWith(".sms") || n.endsWith(".zip");
    }

    private void atualizarPastasAutomaticamente() {
        if (buscandoPastas) {
            reexaminarPastas = true;
            return;
        }
        buscandoPastas = true;
        // Reavalia os BIN/ZIP antigos que ja estavam na biblioteca V2/V3,
        // mesmo se vieram de um seletor de arquivos fora da pasta cadastrada.
        final ArrayList<Jogo> antigosSemConsole = new ArrayList<>();
        for (Jogo j : jogos) {
            if (!j.escolhidoManualmente && j.console == RomConsoleDetector.CONFERIR
                    && RomConsoleDetector.exigeLeitura(j.nome)) {
                antigosSemConsole.add(j);
            }
        }
        new Thread(() -> {
            ArrayList<Jogo> novos = new ArrayList<>();
            StringBuilder avisos = new StringBuilder();
            try {
                // Pasta fixa interna do app: caso uma instalacao a preencha, aparece sem permissao.
                File fixa = getExternalFilesDir("roms");
                if (fixa != null) {
                    if (!fixa.exists()) fixa.mkdirs();
                    lerPastaLocal(fixa, novos);
                }

                // ROMs colocadas em app/src/main/assets/roms/ no projeto, se houver.
                lerAssets("roms", novos);

                // Pasta escolhida anteriormente (exemplo: Download/KIKO_Mega Drive e Master System/roms).
                String tree = getSharedPreferences(PREFS, MODE_PRIVATE)
                    .getString(KEY_TREE, null);
                if (tree != null && !tree.isEmpty()) {
                    Uri raiz = Uri.parse(tree);
                    lerPastaAutorizada(raiz, DocumentsContract.getTreeDocumentId(raiz), novos);
                }
            } catch (Exception e) {
                avisos.append(e.getMessage());
            }
            // Complementa a identificacao dos arquivos salvos antes da V4.
            // Nao reabre ZIPs que ja foram analisados no escaneamento acima.
            Set<String> lidos = new HashSet<>();
            for (Jogo j : novos) lidos.add(j.uri);
            for (Jogo j : antigosSemConsole) {
                if (lidos.add(j.uri)) {
                    int reconhecido = identificarRom(j.nome, j.uri);
                    if (reconhecido != RomConsoleDetector.CONFERIR) {
                        novos.add(new Jogo(j.nome, j.uri, false, reconhecido, false));
                    }
                }
            }
            runOnUiThread(() -> {
                // Se Android recriou a tela, nao atualizar Views antigas.
                if (isFinishing() || isDestroyed()) return;
                // Atualizacao em tempo linear: bibliotecas com milhares de ROMs
                // nao travam a thread da interface ao reclassificar BIN/ZIP.
                java.util.HashMap<String, Jogo> existentes = new java.util.HashMap<>();
                for (Jogo j : jogos) existentes.put(j.uri, j);
                int adicionados = 0;
                boolean atualizouConsole = false;
                for (Jogo j : novos) {
                    Jogo antigo = existentes.get(j.uri);
                    if (antigo == null) {
                        jogos.add(j);
                        existentes.put(j.uri, j);
                        adicionados++;
                    } else if (!antigo.escolhidoManualmente && antigo.console != j.console) {
                        // Nunca perder favoritos, nome nem escolhas manuais.
                        antigo.console = j.console;
                        atualizouConsole = true;
                    }
                }
                if (adicionados > 0 || atualizouConsole) salvarJogos();
                buscandoPastas = false;
                if (paginaAtual == 1 || paginaAtual == 2) mostrarPagina(paginaAtual);
                if (reexaminarPastas) {
                    reexaminarPastas = false;
                    atualizarPastasAutomaticamente();
                }
                if (avisos.length() > 0) {
                    Toast.makeText(this, "Aviso ao ler pasta: " + avisos,
                        Toast.LENGTH_LONG).show();
                }
            });
        }).start();
    }

    private void lerPastaLocal(File dir, ArrayList<Jogo> destino) {
        File[] arquivos = dir.listFiles();
        if (arquivos == null) return;
        for (File f : arquivos) {
            if (f.isDirectory()) {
                lerPastaLocal(f, destino);
            } else if (f.isFile() && eRom(f.getName())) {
                String endereco = Uri.fromFile(f).toString();
                destino.add(new Jogo(f.getName(), endereco, false,
                        identificarRom(f.getName(), endereco), false));
            }
        }
    }

    private void lerAssets(String pasta, ArrayList<Jogo> destino) throws IOException {
        String[] filhos = getAssets().list(pasta);
        if (filhos == null) return;
        for (String nome : filhos) {
            String caminho = pasta + "/" + nome;
            String[] interior = getAssets().list(caminho);
            if (interior != null && interior.length > 0) {
                lerAssets(caminho, destino);
            } else if (eRom(nome)) {
                String endereco = "assetrom:" + caminho;
                destino.add(new Jogo(nome, endereco, false,
                        identificarRom(nome, endereco), false));
            }
        }
    }

    private Uri prepararRomEmAssets(String caminho) throws Exception {
        File pasta = new File(getCacheDir(), "roms_embutidas");
        if (!pasta.exists() && !pasta.mkdirs())
            throw new IOException("Não foi possível preparar a ROM embutida.");
        String nome = caminho.substring(caminho.lastIndexOf('/') + 1);
        String chave = Integer.toHexString(caminho.hashCode());
        File destino = new File(pasta, chave + "_" + nome);
        if (!destino.isFile() || destino.length() == 0) {
            try (InputStream entrada = getAssets().open(caminho);
                 OutputStream saida = new FileOutputStream(destino)) {
                byte[] buffer = new byte[16384];
                int n;
                while ((n = entrada.read(buffer)) != -1)
                    saida.write(buffer, 0, n);
            }
        }
        return Uri.fromFile(destino);
    }

    private void lerPastaAutorizada(Uri arvore, String pastaId,
                                    ArrayList<Jogo> destino) {
        Uri filhos = DocumentsContract.buildChildDocumentsUriUsingTree(arvore, pastaId);
        try (Cursor cursor = getContentResolver().query(filhos,
                new String[]{Document.COLUMN_DOCUMENT_ID,
                    Document.COLUMN_DISPLAY_NAME, Document.COLUMN_MIME_TYPE},
                null, null, null)) {
            if (cursor == null) return;
            while (cursor.moveToNext()) {
                String id = cursor.getString(0);
                String nome = cursor.getString(1);
                String tipo = cursor.getString(2);
                if (Document.MIME_TYPE_DIR.equals(tipo)) {
                    lerPastaAutorizada(arvore, id, destino);
                } else if (nome != null && eRom(nome)) {
                    Uri uri = DocumentsContract.buildDocumentUriUsingTree(arvore, id);
                    String endereco = uri.toString();
                    destino.add(new Jogo(nome, endereco, false,
                            identificarRom(nome, endereco), false));
                }
            }
        }
    }
    // ===== FIM DA INDEXACAO =====

    private void recuperarJogos() {
        try {
            String conteudo = getSharedPreferences(PREFS, MODE_PRIVATE).getString(KEY_GAMES, "[]");
            JSONArray array = new JSONArray(conteudo);
            for (int i = 0; i < array.length(); i++) {
                JSONObject objeto = array.getJSONObject(i);
                jogos.add(new Jogo(objeto.optString("nome"), objeto.optString("uri"),
                        objeto.optBoolean("favorito", false),
                        objeto.has("console") ? objeto.optInt("console", 0)
                            : RomConsoleDetector.pelaExtensao(objeto.optString("nome")),
                        objeto.optBoolean("manual", false)));
            }
        } catch (Exception ignored) {
            jogos.clear();
        }
    }

    private void salvarJogos() {
        JSONArray array = new JSONArray();
        for (Jogo jogo : jogos) {
            try {
                JSONObject objeto = new JSONObject();
                objeto.put("nome", jogo.nome);
                objeto.put("uri", jogo.uri);
                objeto.put("favorito", jogo.favorito);
                objeto.put("console", jogo.console);
                objeto.put("manual", jogo.escolhidoManualmente);
                array.put(objeto);
            } catch (Exception ignored) {}
        }
        SharedPreferences preferencias = getSharedPreferences(PREFS, MODE_PRIVATE);
        preferencias.edit().putString(KEY_GAMES, array.toString()).apply();
    }

    @Override
    public void onBackPressed() {
        if (paginaAtual != 0) mostrarPagina(0);
        else super.onBackPressed();
    }
}
