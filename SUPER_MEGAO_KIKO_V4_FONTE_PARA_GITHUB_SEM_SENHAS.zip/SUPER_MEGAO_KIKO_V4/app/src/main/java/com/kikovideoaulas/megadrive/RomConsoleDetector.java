package com.kikovideoaulas.megadrive;

import java.io.ByteArrayOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.util.Locale;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;

/**
 * Identifica as ROMs usando a extensao e, nos formatos ambiguos,
 * as assinaturas internas do Mega Drive e Master System.
 * Nao le uma ROM inteira na memoria, so o cabecalho (ate 34 KiB).
 */
public final class RomConsoleDetector {
    public static final int CONFERIR = 0;
    public static final int MEGA_DRIVE = 1;
    public static final int MASTER_SYSTEM = 2;
    private static final int CABECALHO_MAX = 0x8400;

    private RomConsoleDetector() {}

    public static int pelaExtensao(String nome) {
        if (nome == null) return CONFERIR;
        String n = nome.toLowerCase(Locale.ROOT);
        if (n.endsWith(".sms")) return MASTER_SYSTEM;
        if (n.endsWith(".md") || n.endsWith(".gen") || n.endsWith(".smd"))
            return MEGA_DRIVE;
        return CONFERIR; // .bin e .zip precisam ser analisados
    }

    public static boolean exigeLeitura(String nome) {
        if (nome == null) return false;
        String n = nome.toLowerCase(Locale.ROOT);
        return n.endsWith(".bin") || n.endsWith(".zip");
    }

    public static int identificar(String nome, InputStream fonte) throws IOException {
        int certo = pelaExtensao(nome);
        if (certo != CONFERIR || !exigeLeitura(nome) || fonte == null) return certo;
        if (nome.toLowerCase(Locale.ROOT).endsWith(".zip")) {
            // Mesma regra do RomInstaller: primeira ROM compativel dentro do ZIP.
            ZipInputStream zip = new ZipInputStream(fonte);
            ZipEntry item;
            while ((item = zip.getNextEntry()) != null) {
                String nomeInterno = item.getName();
                if (!item.isDirectory() && formatoSuportado(nomeInterno)) {
                    int pelaExtensao = pelaExtensao(nomeInterno);
                    if (pelaExtensao != CONFERIR) return pelaExtensao;
                    return cabecalho(lerAte(zip, CABECALHO_MAX));
                }
                zip.closeEntry();
            }
            return CONFERIR;
        }
        return cabecalho(lerAte(fonte, CABECALHO_MAX));
    }

    public static int identificarCabecalhoBin(InputStream fonte) throws IOException {
        if (fonte == null) return CONFERIR;
        return cabecalho(lerAte(fonte, CABECALHO_MAX));
    }

    public static boolean formatoSuportado(String nome) {
        if (nome == null) return false;
        String n = nome.toLowerCase(Locale.ROOT);
        return n.endsWith(".md") || n.endsWith(".gen") || n.endsWith(".smd")
                || n.endsWith(".sms") || n.endsWith(".bin");
    }

    private static byte[] lerAte(InputStream in, int limite) throws IOException {
        ByteArrayOutputStream buffer = new ByteArrayOutputStream(Math.min(limite, 8192));
        byte[] pedaco = new byte[4096];
        int total = 0;
        while (total < limite) {
            int n = in.read(pedaco, 0, Math.min(pedaco.length, limite - total));
            if (n < 0) break;
            if (n == 0) continue;
            buffer.write(pedaco, 0, n);
            total += n;
        }
        return buffer.toByteArray();
    }

    private static int cabecalho(byte[] b) {
        // SMS: "TMR SEGA" no cabecalho (inclui dumps com header extra de 512 B).
        for (int deslocamento : new int[]{0, 512}) {
            for (int pos : new int[]{0x1ff0, 0x3ff0, 0x7ff0}) {
                if (igual(b, pos + deslocamento, "TMR SEGA")) return MASTER_SYSTEM;
            }
        }
        // Mega Drive / Genesis: assinatura "SEGA" a partir de 0x100.
        // Alguns dumps tem cabecalho adicional de 512 bytes.
        if (igual(b, 0x100, "SEGA") || igual(b, 0x300, "SEGA")) return MEGA_DRIVE;
        return CONFERIR;
    }

    private static boolean igual(byte[] dados, int indice, String texto) {
        if (indice < 0 || indice + texto.length() > dados.length) return false;
        for (int i = 0; i < texto.length(); i++) {
            if ((dados[indice + i] & 255) != (int) texto.charAt(i)) return false;
        }
        return true;
    }
}
