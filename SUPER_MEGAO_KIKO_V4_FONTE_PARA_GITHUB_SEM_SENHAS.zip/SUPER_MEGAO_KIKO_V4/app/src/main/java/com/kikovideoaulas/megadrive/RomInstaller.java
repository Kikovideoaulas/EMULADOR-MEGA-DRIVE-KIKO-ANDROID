package com.kikovideoaulas.megadrive;

import android.content.Context;
import android.net.Uri;

import java.io.File;
import java.io.FileOutputStream;
import java.io.InputStream;
import java.io.OutputStream;
import java.security.MessageDigest;
import java.util.Locale;
import java.util.zip.ZipEntry;
import java.util.zip.ZipInputStream;

/** ROMs sao copiadas para armazenamento interno acessivel ao nucleo nativo. */
public final class RomInstaller {
    private static final long MAX_ROM = 48L * 1024 * 1024;
    private RomInstaller() {}

    public static File preparar(Context c, Uri origem, String nome) throws Exception {
        return preparar(c, origem, nome, RomConsoleDetector.CONFERIR);
    }

    public static File preparar(Context c, Uri origem, String nome, int consoleManual)
            throws Exception {
        if (origem == null) throw new Exception("Arquivo nao encontrado.");
        String nomeLower = nome.toLowerCase(Locale.ROOT);
        File pasta = new File(c.getFilesDir(), "roms");
        if (!pasta.exists() && !pasta.mkdirs()) throw new Exception("Erro ao criar a pasta das ROMs.");
        String chave = hash(origem.toString());
        boolean compactado = nomeLower.endsWith(".zip");
        // Diferencia .bin de Master System e Mega Drive pelo cabecalho real.
        // Genesis Plus GX identifica Master System com extensao .sms.
        String extensao = "";
        if (!compactado) {
            extensao = extensaoSuportada(nomeLower);
            if (extensao == null) throw new Exception("Use .md, .gen, .bin, .smd, .sms ou .zip.");
            if (".bin".equals(extensao)) {
                int console = consoleManual;
                if (console == RomConsoleDetector.CONFERIR) {
                    try (InputStream bin = c.getContentResolver().openInputStream(origem)) {
                        console = RomConsoleDetector.identificarCabecalhoBin(bin);
                    }
                }
                if (console == RomConsoleDetector.MASTER_SYSTEM) extensao = ".sms";
            }
        } else {
            // Mesma primeira ROM do ZIP que sera usada na extracao abaixo.
            try (InputStream bruto = c.getContentResolver().openInputStream(origem)) {
                if (bruto == null) throw new Exception("Sem acesso ao arquivo ZIP.");
                ZipInputStream zip = new ZipInputStream(bruto);
                ZipEntry item;
                while ((item = zip.getNextEntry()) != null) {
                    if (!item.isDirectory()) {
                        extensao = extensaoSuportada(item.getName().toLowerCase(Locale.ROOT));
                        if (extensao != null) {
                            if (".bin".equals(extensao)) {
                                int console = consoleManual;
                                if (console == RomConsoleDetector.CONFERIR) {
                                    console = RomConsoleDetector.identificarCabecalhoBin(zip);
                                }
                                if (console == RomConsoleDetector.MASTER_SYSTEM) extensao = ".sms";
                            }
                            break;
                        }
                    }
                    zip.closeEntry();
                }
            }
            if (extensao == null) throw new Exception("ZIP sem jogo Mega Drive ou Master System valido.");
        }
        File saida = new File(pasta, chave + extensao);
        if (saida.isFile() && saida.length() > 0 && saida.length() <= MAX_ROM) return saida;

        File temporario = new File(pasta, chave + ".tmp");
        if (temporario.exists()) temporario.delete();
        try {
            try (InputStream bruto = c.getContentResolver().openInputStream(origem)) {
                if (bruto == null) throw new Exception("Sem acesso ao arquivo. Importe a ROM novamente.");
                if (compactado) {
                    ZipInputStream zip = new ZipInputStream(bruto);
                    ZipEntry entrada;
                    boolean achou = false;
                    while ((entrada = zip.getNextEntry()) != null) {
                        String dentro = entrada.getName().toLowerCase(Locale.ROOT);
                        if (!entrada.isDirectory() && (extensaoSuportada(dentro) != null)) {
                            try (OutputStream out = new FileOutputStream(temporario)) {
                                copiarLimitado(zip, out);
                            }
                            achou = true;
                            break;
                        }
                        zip.closeEntry();
                    }
                    if (!achou) throw new Exception("O ZIP nao contem ROM Sega .md, .gen, .bin, .smd ou .sms.");
                } else if (extensaoSuportada(nomeLower) != null) {
                    try (OutputStream out = new FileOutputStream(temporario)) {
                        copiarLimitado(bruto, out);
                    }
                } else {
                    throw new Exception("Formato nao suportado: use .md, .gen, .bin, .smd, .sms ou .zip.");
                }
            }
            if (temporario.length() < 1024) throw new Exception("A ROM esta vazia ou muito pequena.");
            if (saida.exists()) saida.delete();
            if (!temporario.renameTo(saida)) throw new Exception("Nao foi possivel salvar a ROM.");
            return saida;
        } finally {
            if (temporario.exists()) temporario.delete();
        }
    }

    private static String extensaoSuportada(String nome) {
        for (String ext : new String[]{".md", ".gen", ".bin", ".smd", ".sms"}) {
            if (nome.endsWith(ext)) return ext;
        }
        return null;
    }

    private static void copiarLimitado(InputStream in, OutputStream out) throws Exception {
        byte[] buffer = new byte[16384];
        int lido;
        long total = 0;
        while ((lido = in.read(buffer)) != -1) {
            total += lido;
            if (total > MAX_ROM) throw new Exception("ROM muito grande: limite de 48 MB.");
            out.write(buffer, 0, lido);
        }
    }

    private static String hash(String entrada) throws Exception {
        byte[] bits = MessageDigest.getInstance("SHA-256").digest(entrada.getBytes("UTF-8"));
        StringBuilder sb = new StringBuilder();
        for (int i = 0; i < 12; i++) sb.append(String.format(Locale.ROOT, "%02x", bits[i] & 255));
        return sb.toString();
    }
}
